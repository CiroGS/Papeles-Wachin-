class Tarjeta {


  int x, y, offsetX, offsetY, destinoX, destinoY, ancho, largo, ancho1, largo1, ancho2, largo2, numero;

  boolean agarrado, animando, mostrarTarjeta, tarjetaDevuelta;

  String titulo, contenido;

  Tarjeta() {
    tarjetaDevuelta = false;
  }

  void generarTarjeta(int numTarjeta) {
    if (numTarjeta == 0) {
      numero = numTarjeta;
      ancho = 75;
      largo = 50;
      ancho1 = ancho;
      largo1 = largo;
      ancho2 = ancho * 3;
      largo2 = largo * 3;
      x = width / 2 - width / 10;
      y = height - height / 3;
      destinoX = x;
      destinoY = y;
      mostrarTarjeta = true;
      tarjetaDevuelta = false;
      titulo = "ORG";
    }
    if (numTarjeta == 1) {
      numero = numTarjeta;
      ancho = 60;
      largo = 100;
      ancho1 = ancho;
      largo1 = largo;
      ancho2 = ancho * 3;
      largo2 = largo * 3;
      x = width / 2 - width / 10;
      y = height - height / 3;
      destinoX = x;
      destinoY = y;
      mostrarTarjeta = true;
      tarjetaDevuelta = false;
      titulo = "NARC";
    }
  }

  void mostrar() {
    // Tarjeta
    fill(100);
    rect(x, y, ancho, largo);
    fill(255);
    textAlign(CENTER);
    if (x <= width /2) {
      textSize(20);
      text(titulo, x+ancho/2, y+largo/2);
    }

    if (x > width / 2) {
      if (numero == 0) {
        //mostrarDatos();
        textSize(30);
        textAlign(CENTER);
        text("MARCOS LUNA", x+ancho/2, y+largo/2);
        textSize(20);
        text("*DEVOLVER A MARCOS*", x+ancho/2, y+largo -largo/4);
      }
      if (numero == 1) {
        fill(0);
        textSize(20);
        textAlign(LEFT, TOP);

        text(
          "NOMBRES BUSCADOS:\n\n" +
          "x Juan Perez\n" +
          "- Carlos Medina\n" +
          "x Miguel Torres\n" +
          "- Diego Ramirez\n" +
          "M Pablo Fernandez",
          x + 10,
          y + 10,
          ancho2 - 20,
          largo2 - 20
          );
      }
    }
  }


  void mousePressed() {
    if (mouseX >= x &&
      mouseX <= x + ancho &&
      mouseY >= y &&
      mouseY <= y + largo) {
      agarrado = true;
      offsetX = mouseX - x;
      offsetY = mouseY - y;
    }
  }

  void mouseReleased() {
    agarrado = false;
  }

  void actualizar() {
    if (agarrado) {
      x = mouseX - offsetX;
      y = mouseY - offsetY;

      if (x>width/2) {
        ancho = ancho2;
        largo = largo2;
      } else {
        ancho = ancho1;
        largo = largo1;
      }
    }

    if (x <= width / 2 && agarrado == false) {
      animando = true;

      if (x > destinoX + -50 && x < destinoX + 50 && y > destinoY - 50 && destinoY < destinoY + 50) {
        animando = false;
      }

      if (x > destinoX + 50) {
        x -= 50;
      } else if (x < destinoX - 50) {
        x += 50;
      } else {
        x = destinoX;
      }
      if (y > destinoY + 50) {
        y -= 50;
      } else if (y < destinoY - 50) {
        y += 50;
      } else {
        y = destinoY;
      }
    }

    if ((x < width / 2 && y < height / 2) && (fecha.dia == personaje.marcosDia && personajesAtendidos == personaje.marcosFila)) {
      fill(0);
      textSize(20);
      textAlign(CENTER);
      text("*DEVOLVER*", x + ancho/2, y - 10);
      if (agarrado == false) {
        mostrarTarjeta = false;
        tarjetaDevuelta = true;
      }
    }
    
    if (x < width / 2 && y < height / 2 && fecha.dia == personaje.narcoDia && personajesAtendidos == personaje.narcoFila) {
      fill(0);
      textSize(20);
      textAlign(CENTER);
      text("*DEVOLVER*", x + ancho/2, y - 10);
      if (agarrado == false) {
        mostrarTarjeta = false;
        tarjetaDevuelta = true;
        segundaMisionOrganizacion = true;
      }
    }
    
  }
}
