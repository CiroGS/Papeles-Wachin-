class BotonNoPasa {
  int x, y, ancho, largo;

  BotonNoPasa() {
    x = width / 4;
    y = height - height / 10;
    ancho = 100;
    largo = 50;
  }
  void mostrar() {
    fill(255, 0, 0);
    rect(x, y, 100, 50);
  }

  void mousePressed() {
    //if (personaje.animacionEnCurso == false) {

    if (mouseX >= x &&
      mouseX <= x + ancho &&
      mouseY >= y &&
      mouseY <= y + largo) {
      personajesAtendidos++;


      if (personaje.esIngresante) {
        verificacion.verificarNoPasa();
      }
      personaje.nuevoPersonaje();

      if (personajesAtendidos == fecha.maxIngresantes) {
        finaldia.pantalla();
        estado = 4;
      }
    }
  }
  //}
}
