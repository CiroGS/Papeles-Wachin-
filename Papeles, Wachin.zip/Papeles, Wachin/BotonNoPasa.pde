class BotonNoPasa {
  int x, y, ancho, largo;
  boolean pasa;
  int tiempoEspera = 2000; // 2 segundos
  int tiempoInicio;
  boolean esperandoPersonaje = false;

  BotonNoPasa() {
    x = width / 4;
    y = height - height / 10;
    ancho = 100;
    largo = 50;
    pasa = false;
  }
  void mostrar() {
    fill(255, 0, 0);
    rect(x, y, 100, 50);
  }

  void mousePressed() {
    //if (personaje.animacionEnCurso == false) {

    if (mouseX >= x &&
      mouseX <= x + ancho &&
      mouseY >= y &&
      mouseY <= y + largo) {




      if (personaje.esIngresante) {
        verificacion.verificarNoPasa();
      }
      if (fecha.dia == personaje.narcoDia && personajesAtendidos == personaje.narcoFila) {
        animaciones.animacionNarco(pasa);
      } else if (fecha.dia == personaje.espiaDia && personajesAtendidos == personaje.espiaFila) {
        
      } else {
        personajesAtendidos++;
        personaje.nuevoPersonaje();



        if (personajesAtendidos >= fecha.maxIngresantes) {
          finaldia.pantalla();
          estado = 4;
        }
      }
    }
  }

  //}
}
