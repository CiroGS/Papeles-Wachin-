class BotonPasa {
  int x, y, ancho, largo;
  boolean pasa;

  BotonPasa() {
    x = width / 8;
    y = height - height / 10;
    ancho = 100;
    largo = 50;
    pasa = true;
  }
  void mostrar() {
    fill(0, 255, 0);
    rect(x, y, ancho, largo);
  }

  void mousePressed() {
    //if(personaje.animacionEnCurso == false){

    if (mouseX >=width / 8 &&
      mouseX <= width / 8 + ancho &&
      mouseY >= height - height / 10 &&
      mouseY <= height - height / 10 + largo) {
      //IF CHEQUEA MISIONES
      if (fecha.dia == personaje.marcosDia && personajesAtendidos == personaje.marcosFila) {
        primerMisionOrganizacion = true;
      }
      
      



      if (personaje.esIngresante) {
        verificacion.verificarPasa();
      }
      if (fecha.dia == personaje.narcoDia && personajesAtendidos == personaje.narcoFila) {
        animaciones.animacionNarco(pasa);
      } else {
        personajesAtendidos++;
        personaje.nuevoPersonaje();

        if (personajesAtendidos >= fecha.maxIngresantes) {
          finaldia.pantalla();
          estado = 4;
        }
      }
    }
    //}
  }
}
