class Arma {
  int x, y, ancho, largo, offsetX, offsetY, destinoX, destinoY;
  boolean agarrado, animando, mostrarArma, armaHabilitada;

  PImage imgArma;

  Arma() {
    armaHabilitada = true;
    x = width / 2 - width / 4;
    y = height - height / 3;

    imgArma = loadImage("arma.png");
  }

  void generarArma() {

    ancho = 50;
    largo = 30;
    x = width / 2 - width / 4;
    y = height - height / 3;
    destinoX = x;
    destinoY = y;
    mostrarArma = true;
  }

  void mostrar() {
    if (mostrarArma) {
      image(imgArma, x, y, ancho * 4, largo * 4);
    }
  }

  void mousePressed() {
    if (mouseX >= x &&
      mouseX <= x + ancho * 4 &&
      mouseY >= y &&
      mouseY <= y + largo * 4) {

      agarrado = true;
      offsetX = mouseX - x;
      offsetY = mouseY - y;
    }
  }

  void mouseReleased() {
    agarrado = false;
  }

  void actualizar() {
    if (mostrarArma) {
      if (agarrado) {
        x = mouseX - offsetX;
        y = mouseY - offsetY;

        if (x > width / 2) {
          ancho = 150;
          largo = 90;
        } else {
          ancho = 50;
          largo = 30;
        }
      }
      if (x <= width / 2 && agarrado == false) {
        animando = true;

        if (x > destinoX + -50 && x < destinoX + 50 && y > destinoY - 50 && destinoY < destinoY + 50) {
          animando = false;
        }

        if (x > destinoX + 50) {
          x -= 50;
        } else if (x < destinoX - 50) {
          x += 50;
        } else {
          x = destinoX;
        }
        if (y > destinoY + 50) {
          y -= 50;
        } else if (y < destinoY - 50) {
          y += 50;
        } else {
          y = destinoY;
        }
      }
    }

    if ((x < width / 2 && y < height / 2) && (fecha.dia == personaje.inspectorDiaUlt && personajesAtendidos == personaje.inspectorFilaUlt)) {
      fill(0);
      textSize(20);
      textAlign(CENTER);
      text("*MATAR*", x + ancho/2, y - 10);
      if (armaHabilitada) {

        if (agarrado == false) {
          mostrarArma = false;
          armaHabilitada = false;
          terceraMisionOrganizacion = true;
          if (primerMisionOrganizacion == true) {
            finalJuego = 6;
          } else if (primerMisionOrganizacion == false) {
            finalJuego = 7;
          }
        }
      }
    }
    if ((x < width / 2 && y < height / 2) && (fecha.dia == personaje.liderDia && personajesAtendidos == personaje.liderFila)) {
      fill(0);
      textSize(20);
      textAlign(CENTER);
      text("*DEVOLVER*", x + ancho/2, y - 10);
      if (agarrado == false) {
        mostrarArma = false;
        armaHabilitada = false;
      }
    }
  }
}
