class Cinematica {//Se muestra al iniciar el juego

  int pantalla = 0;
  boolean inicializado = false;

  Cinematica() {
    pantalla = 0;
  }


  void mostrar() {
    background(0);
    if (pantalla == 1) {
      textSize(30);
      text(
        "ARGENTINA — 2020\n\n" +
        "El país atraviesa una situación excepcional.\n" +
        "Los puntos de acceso se encuentran bajo estrictos\n" +
        "controles de ingreso.\n\n",

        width / 10,
        height / 10
        );
    } else if (pantalla == 2) {
      textSize(30);
      text("A partir de hoy, usted estará a cargo de una\n" +
        "garita de control.\n\n" +
        "Su tarea es revisar los documentos de cada persona\n" +
        "que intente ingresar.\n\n", width / 10, height / 10);
    } else if (pantalla == 3) {
      textSize(30);
      text("Compruebe sus datos, revise las fechas y busque\n" +
        "cualquier inconsistencia.\n\n" +
        "Si todo está en orden, déjelos pasar.\n" +
        "Si encuentra una irregularidad, rechace el ingreso.\n\n" +
        "Una decisión incorrecta tendrá consecuencias.\n\n", width / 10, height / 10);
    } else if (pantalla == 4) {
      textSize(100);
      text("Buena suerte, wachín.", width / 10, height / 2);
    }

    if (pantalla > 4) {
      estado = 1;
    }
  }

  void mostrarFinal2() {
    if (!inicializado) {
      pantalla = 0;
      inicializado = true;
    }
    if (pantalla == 0) {
      frame = loadImage("Final 2/frame1Final2.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 1) {
      frame = loadImage("Final 2/frame2Final2.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 2) {
      frame = loadImage("Final 2/frame3Final2.png");
      image(frame, 0, 0, width, height);
    }
    if(pantalla == 3){
      estado = 0;
      finalJuego = 0;
      inicializado = false;
    }
  }
  void mostrarFinal3() {
    if (!inicializado) {
      pantalla = 0;
      inicializado = true;
    }
    if (pantalla == 0) {
      frame = loadImage("Final 3/frame1Final3.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 1) {
      frame = loadImage("Final 3/frame2Final3.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 2) {
      frame = loadImage("Final 3/frame3Final3.png");
      image(frame, 0, 0, width, height);
    }
    if(pantalla == 3){
      estado = 0;
      finalJuego = 0;
      inicializado = false;
    }
  }
  void mostrarFinal4() {
    if (!inicializado) {
      pantalla = 0;
      inicializado = true;
    }
    if (pantalla == 0) {
      frame = loadImage("Final 4/frame1Final4.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 1) {
      frame = loadImage("Final 4/frame2Final4.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 2) {
      frame = loadImage("Final 4/frame3Final4.png");
      image(frame, 0, 0, width, height);
    }
    if(pantalla == 3){
      estado = 0;
      finalJuego = 0;
      inicializado = false;
    }
  }
  void mostrarFinal5() {
    if (!inicializado) {
      pantalla = 0;
      inicializado = true;
    }
    if (pantalla == 0) {
      frame = loadImage("Final 5/frame1Final5.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 1) {
      frame = loadImage("Final 5/frame2Final5.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 2) {
      frame = loadImage("Final 5/frame3Final5.png");
      image(frame, 0, 0, width, height);
    }
    if(pantalla == 3){
      estado = 0;
      finalJuego = 0;
      inicializado = false;
    }
  }
  void mostrarFinal6() {
    if (!inicializado) {
      pantalla = 0;
      inicializado = true;
    }
    if (pantalla == 0) {
      frame = loadImage("Final 6/frame1Final6.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 1) {
      frame = loadImage("Final 6/frame2Final6.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 2) {
      frame = loadImage("Final 6/frame3Final6.png");
      image(frame, 0, 0, width, height);
    }
    if(pantalla == 3){
      estado = 0;
      finalJuego = 0;
      inicializado = false;
    }
  }
  void mostrarFinal7() {
    if (!inicializado) {
      pantalla = 0;
      inicializado = true;
    }
    if (pantalla == 0) {
      frame = loadImage("Final 7/frame1Final7.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 1) {
      frame = loadImage("Final 7/frame2Final7.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 2) {
      frame = loadImage("Final 7/frame3Final7.png");
      image(frame, 0, 0, width, height);
    }
    if(pantalla == 3){
      estado = 0;
      finalJuego = 0;
      inicializado = false;
    }
  }
  void mostrarFinal8() {
    if (!inicializado) {
      pantalla = 0;
      inicializado = true;
    }
    if (pantalla == 0) {
      frame = loadImage("Final 8/frame1Final8.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 1) {
      frame = loadImage("Final 8/frame2Final8.png");
      image(frame, 0, 0, width, height);
    }
    if (pantalla == 2) {
      frame = loadImage("Final 8/frame3Final8.png");
      image(frame, 0, 0, width, height);
    }
    if(pantalla == 3){
      estado = 0;
      finalJuego = 0;
      inicializado = false;
    }
  }

  void mousePressed() {
    pantalla++;
  }
}
