class Cinematica {  //Se muestra al iniciar el juego
int pantalla = 0;

  void mostrar(){
    background(0);
    if(pantalla == 1){
      textSize(30);
      text(
        "ARGENTINA — 2020\n\n" +
        "El país atraviesa una situación excepcional.\n" +
        "Los puntos de acceso se encuentran bajo estrictos\n" +
        "controles de ingreso.\n\n",
        
        width / 10,
        height / 10
      );
    } else if(pantalla == 2){
      textSize(30);
      text("A partir de hoy, usted estará a cargo de una\n" +
        "garita de control.\n\n" +
        "Su tarea es revisar los documentos de cada persona\n" +
        "que intente ingresar.\n\n", width / 10, height / 10);
    
    } else if(pantalla == 3){
      textSize(30);
      text("Compruebe sus datos, revise las fechas y busque\n" +
        "cualquier inconsistencia.\n\n" +
        "Si todo está en orden, déjelos pasar.\n" +
        "Si encuentra una irregularidad, rechace el ingreso.\n\n" +
        "Una decisión incorrecta tendrá consecuencias.\n\n", width / 10, height / 10);
    } else if(pantalla == 4) {
      textSize(100);
      text("Buena suerte, wachín.", width / 10, height / 2);
    }
    
    if(pantalla > 4){
      estado = 1;
    }
  }
  
  void mousePressed(){
      pantalla++;
  }
  
}
