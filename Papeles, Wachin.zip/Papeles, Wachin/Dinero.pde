class Dinero {

  color colCuadrado;
  int dinero, dineroMostrado, dineroDescontado;
  int cuotaDiaria;
  int i;
  boolean cuotaPagada;

  String mensaje;

  Dinero() {
    dinero = 300;
    cuotaDiaria = 250;
    colCuadrado = color(255, 0, 0);
  }

  void cobrar() {
    dinero += 300;
  }
  
  void pagar() {
    dinero -= cuotaDiaria;
  }
  

  void perder() {
    estado = 3;
  }

  void mostrar() {

    
    if(cuotaPagada){
      dineroMostrado = dinero - cuotaDiaria;
    } else {
      dineroMostrado = dinero;
    }
    fill(255);
    textSize(35);
    textAlign(CENTER, CENTER);

    text("Dinero: $" + dineroMostrado, width / 2, height - height / 3);
    text("Cuota: $" + cuotaDiaria, width / 2, height - height / 3 +40);

    fill(colCuadrado);
    square(width / 2 - 110, height - height / 3 + 30, 20);
  }

  void actualizar() {
  }

  void mousePressed() {
    if (mouseX >= width / 2 - 110 &&
      mouseX <= width / 2 - 110 + 20 &&
      mouseY >= height - height / 3 + 30 &&
      mouseY <= height - height / 3 + 30 + 20) {
        i++;
        if(i % 2 == 1){
          if(dinero - cuotaDiaria >= 0){
            colCuadrado = color(0, 255, 0);
            cuotaPagada = true;
          } else {
            finaldia.mostrandoCuota = true;
            finaldia.tiempoCuota = millis();
            finaldia.mensaje = "Dinero insuficiente";
          }
          
        } else{
          colCuadrado = color(255, 0, 0);
          cuotaPagada = false;
          
        }
        
    }
  }
}
