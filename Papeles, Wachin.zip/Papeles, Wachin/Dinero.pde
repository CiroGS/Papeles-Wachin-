class Dinero {

  color colCuadrado, escaparSolo, escaparFamilia;
  int dinero, dineroMostrado, dineroDescontado;
  int cuotaDiaria, cobroDiario;
  int i, i1, i2;
  boolean cuotaPagada, soloPagada, familiaPagada;

  String mensaje;

  Dinero() {
    dinero = 3000;
    cuotaDiaria = 250;
    colCuadrado = color(255, 0, 0);
    escaparSolo = color(255, 0, 0);
    escaparFamilia = color(255, 0, 0);
  }

  void cobrar() {
    if (fecha.dia == 1) {
      cobroDiario = 300;
    }
    if (fecha.dia == 5) {
      cobroDiario = 200;
    }
    if (fecha.dia == 8) {
      cobroDiario = 250;
    }
    dinero += cobroDiario;
  }

  void pagar() {
    dinero -= cuotaDiaria;
  }


  void perder() {
    estado = 3;
  }

  void mostrar() {


    if (!cuotaPagada  && !soloPagada && !familiaPagada) {
      dineroMostrado = dinero;
    }
    if (!cuotaPagada  && !soloPagada && familiaPagada) {
      dineroMostrado = dinero - 600;
    }
    if (!cuotaPagada  && soloPagada && !familiaPagada) {
      dineroMostrado = dinero - 400;
    }
    if (cuotaPagada  && !soloPagada && !familiaPagada) {
      dineroMostrado = dinero - cuotaDiaria;
    }
    if (cuotaPagada  && !soloPagada && familiaPagada) {
      dineroMostrado = dinero - cuotaDiaria - 600;
    }
    if (cuotaPagada  && soloPagada && !familiaPagada) {
      dineroMostrado = dinero - cuotaDiaria - 400;
    }
    if (!cuotaPagada  && !soloPagada && !familiaPagada) {
      dineroMostrado = dinero;
    }
    fill(255);
    textSize(35);
    textAlign(CENTER, CENTER);

    text("Dinero: $" + dineroMostrado, width / 2, height - height / 3);
    text("Cuota: $" + cuotaDiaria, width / 2, height - height / 3 +40);
    if (fecha.dia >= 8) {
      text("Escapar solo: $400", width / 2, height - height / 3 +80);
      text("Escapar con tu familia: $600", width / 2, height - height / 3 +120);
      fill(escaparSolo);
      square(width / 2 - 160, height - height / 3 + 70, 20);
      fill(escaparFamilia);
      square(width / 2 - 240, height - height / 3 + 110, 20);
    }

    fill(colCuadrado);
    square(width / 2 - 110, height - height / 3 + 30, 20);
  }

  void actualizar() {
  }

  void mousePressed() {
    if (mouseX >= width / 2 - 110 &&
      mouseX <= width / 2 - 110 + 20 &&
      mouseY >= height - height / 3 + 30 &&
      mouseY <= height - height / 3 + 30 + 20) {

      i++;
      if (i % 2 == 1) {
        if (dinero - cuotaDiaria >= 0) {
          colCuadrado = color(0, 255, 0);
          cuotaPagada = true;
        } else {
          finaldia.mostrandoCuota = true;
          finaldia.tiempoCuota = millis();
          finaldia.mensaje = "Dinero insuficiente";
        }
      } else {
        colCuadrado = color(255, 0, 0);
        cuotaPagada = false;
      }
    }
    if (mouseX >= width / 2 - 160 &&
      mouseX <= width / 2 - 90 &&
      mouseY >= height - height / 3 + 70 &&
      mouseY <= height - height / 3 + 90 && fecha.dia >= 8) {
      if (!familiaPagada) {

        i1++;
        if (i1 % 2 == 1) {
          if (dinero - 400 >= 0) {
            escaparSolo = color(0, 255, 0);
            soloPagada = true;
          } else {
            finaldia.mostrandoCuota = true;
            finaldia.tiempoCuota = millis();
            finaldia.mensaje = "Dinero insuficiente";
          }
        } else {
          escaparSolo = color(255, 0, 0);
          soloPagada = false;
        }
      }
    }

    if (mouseX >= width / 2 - 240 &&
      mouseX <= width / 2 - 90 &&
      mouseY >= height - height / 3 + 110 &&
      mouseY <= height - height / 3 + 130 && fecha.dia >= 8) {
      if (!soloPagada) {

        i2++;
        if (i2 % 2 == 1) {
          if (dinero - 600 >= 0) {
            escaparFamilia = color(0, 255, 0);
            familiaPagada = true;
          } else {
            finaldia.mostrandoCuota = true;
            finaldia.tiempoCuota = millis();
            finaldia.mensaje = "Dinero insuficiente";
          }
        } else {
          escaparFamilia = color(255, 0, 0);
          familiaPagada = false;
        }
      }
    }
  }
}
