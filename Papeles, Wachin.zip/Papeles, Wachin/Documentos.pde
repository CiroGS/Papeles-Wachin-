class Documentos {

  int ancho, largo, ancho1, largo1, ancho2, largo2, x, y, destinoX, destinoY, offsetX, offsetY, doc, anchoImg, largoImg;
  boolean agarrado, animando, mostrarDocumentos;
  String titulo;

  Documentos() {
    anchoImg = 30;
    largoImg = 35;
  }

  void generarDocumentos(int numDocumento) {
    doc = numDocumento;
    mostrarDocumentos = true;
    if (numDocumento == 0) {
      ancho = 100;
      largo = 200;
      ancho1 = ancho;
      largo1 = largo;
      ancho2 = ancho * 3;
      largo2 = largo * 3;
      x = width / 2 - width / 3;
      y = height - height / 3;
      destinoX = x;
      destinoY = y;
      titulo = "SEC.>";
    }
    if (numDocumento == 1) {
      ancho = 50;
      largo = 50;
      ancho1 = ancho;
      largo1 = largo;
      ancho2 = ancho * 3;
      largo2 = largo * 3;
      x = width / 2 - width / 3;
      y = height - height / 3;
      destinoX = x;
      destinoY = y;
      titulo = "SEC.>";
    }
    if (numDocumento == 2) {
      ancho = 100;
      largo = 150;
      ancho1 = ancho;
      largo1 = largo;
      ancho2 = ancho * 3;
      largo2 = largo * 3;
      x = width / 2 - width / 3;
      y = height - height / 3;
      destinoX = x;
      destinoY = y;
      titulo = "JEFE";
    }
  }
  void mostrar() {
    if (doc == 0 ) {
      fill(255);
      rect(x, y, ancho, largo);
      fill(0);
      textAlign(CENTER);
      text(titulo, x+ancho/2, y+largo/2);
    }
    if (doc == 1 ) {
      fill(255);
      rect(x, y, ancho, largo);
      fill(0);
      textAlign(CENTER);
      text(titulo, x+ancho/2, y+largo/2);
    }
    if (doc == 2 ) {
      fill(255);
      rect(x, y, ancho, largo);
      fill(0);
      textAlign(CENTER);
      text(titulo, x+ancho/2, y+largo/2);
    }
  }

  void mousePressed() {
    if (mouseX >= x &&
      mouseX <= x + ancho &&
      mouseY >= y &&
      mouseY <= y + largo) {
      agarrado = true;
      offsetX = mouseX - x;
      offsetY = mouseY - y;
    }
  }

  void mouseReleased() {
    agarrado = false;
  }

  void actualizar() {
    if (x>width/2) {
      ancho = ancho2;
      largo = largo2;
      if (doc == 1) {
        pushStyle();
        imageMode(CENTER);
        liderCara = loadImage("caraLider.png");
        image(liderCara, x + ancho2/2, y + largo2/2, anchoImg * 3, largoImg * 3);
        popStyle();
      }
    } else {
      ancho = ancho1;
      largo = largo1;
    }
    if (agarrado) {
      x = mouseX - offsetX;
      y = mouseY - offsetY;
    }

    if (x <= width / 2 && agarrado == false) {
      animando = true;

      if (x > destinoX + -50 && x < destinoX + 50 && y > destinoY - 50 && destinoY < destinoY + 50) {
        animando = false;
      }

      if (x > destinoX + 50) {
        x -= 50;
      } else if (x < destinoX - 50) {
        x += 50;
      } else {
        x = destinoX;
      }
      if (y > destinoY + 50) {
        y -= 50;
      } else if (y < destinoY - 50) {
        y += 50;
      } else {
        y = destinoY;
      }
    }

    if ((x < width / 2 && y < height / 2) && (fecha.dia == personaje.espiaDia && personajesAtendidos == personaje.espiaFila) && doc == 0) {
      fill(0);
      textSize(20);
      textAlign(CENTER);
      text("*DEVOLVER*", x + ancho/2, y - 10);
      if (agarrado == false) {
        mostrarDocumentos = false;
        primerMisionGobierno = true;
        animaciones.animacionEspia = true;
        personaje.dialogoEspecial = true;
      }
    }

    if (x < width / 2 && y < height / 2) {

      fill(0);
      textSize(20);
      textAlign(CENTER);
      text("*DAR*", x + ancho/2, y - 10);
      if (agarrado == false) {
        if (fecha.dia == personaje.segundoLiderDia && personajesAtendidos == personaje.segundoLiderFila && doc == 2) {
          mostrarDocumentos = false;
          terceraMisionGobierno = true;
        }
      }
    }
  }
}
