class Juego {

  void mostrar() {
    float escala = max(
      (float)width / garita.width,
      (float)height / garita.height
      );

    float ancho = fondo.width * escala;
    float alto = fondo.height * escala;

    float x = (width - ancho) / 2;
    float y = (height - alto) / 2;

    image(garita, x, y, ancho, alto);
    botonPasa.mostrar();
    botonNoPasa.mostrar();

    personaje.mostrar();
    animaciones.animacion();
    if (barbijo.barbijoPuesto) {
      barbijo.mostrar();
    }

    manual.mostrar();
    manual.actualizar();
    arma.mostrar();
    arma.actualizar();


    verificacion.mostrarPenalizacion();
    if (personaje.extranjero) {
      if (animaciones.animacionTerminada) {
        if (pasaporte.muestraPasaporte) {
          pasaporte.mostrar();
          pasaporte.actualizar();
        }
      }
    } else {
      if (animaciones.animacionTerminada) {
        if (dni.muestraDNI) {
          dni.mostrar();
          dni.actualizar();
        }
      }
    }

    if (animaciones.animacionTerminada && personaje.permisoMostrado) {
      permiso.mostrar();
      permiso.actualizar();
    }

    dialogo.mostrar();
    fecha.mostrar();


    if (tarjeta.mostrarTarjeta) {
      tarjeta.mostrar();
      tarjeta.actualizar();
    }
    
    if (veneno.mostrarVeneno){
      veneno.mostrar();
      veneno.actualizar();
    }

    if (documentos.mostrarDocumentos == true) {
      documentos.mostrar();
      documentos.actualizar();
    }
  }
}
