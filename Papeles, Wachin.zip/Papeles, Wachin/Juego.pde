class Juego {

  void mostrar() {
    float escala = max(
      (float)width / garita.width,
      (float)height / garita.height
      );

    float ancho = fondo.width * escala;
    float alto = fondo.height * escala;

    float x = (width - ancho) / 2;
    float y = (height - alto) / 2;

    image(garita, x, y, ancho, alto);
    botonPasa.mostrar();
    botonNoPasa.mostrar();

    //dia 1 (10 personajes a atender)
    personaje.mostrar();
    personaje.animacion();
    barbijo.mostrar();
    
    manual.mostrar();
    manual.actualizar();
    
    verificacion.mostrarPenalizacion();
    if (personaje.extranjero) {
      if(personaje.animacionTerminada){
        pasaporte.mostrar();
        pasaporte.actualizar();
      }
    } else {
      if(personaje.animacionTerminada){
        dni.mostrar();
        dni.actualizar();
      }
    }
    
    if(personaje.animacionTerminada && personaje.permisoMostrado){
      permiso.mostrar();
      permiso.actualizar();
    }
    
    
    fecha.mostrar();
    
  }
}
