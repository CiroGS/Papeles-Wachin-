class Veneno {

  int x, y, ancho, largo, destinoX, destinoY, offsetX, offsetY;
  boolean mostrarVeneno, agarrado, animando;

  Veneno() {
  }
  void generarVeneno() {
    x = width / 2 - width / 3;
    y = height - height / 3 - height / 20;
    ancho = 30;
    largo = 30;
    destinoX = x;
    destinoY = y;
    mostrarVeneno = true;
  }

  void mostrar() {
    fill(0);
    rect(x, y, ancho, largo);
  }

  void mousePressed() {
    if (mouseX >= x &&
      mouseX <= x + ancho &&
      mouseY >= y &&
      mouseY <= y + largo) {

      agarrado = true;
      offsetX = mouseX - x;
      offsetY = mouseY - y;
    }
  }

  void mouseReleased() {
    agarrado = false;
  }

  void actualizar() {
    if (mostrarVeneno) {
      if (agarrado) {
        x = mouseX - offsetX;
        y = mouseY - offsetY;

        if (x > width / 2) {
          ancho = 90;
          largo = 90;
        } else {
          ancho = 30;
          largo = 30;
        }
      }
      if (x <= width / 2 && agarrado == false) {
        animando = true;

        if (x > destinoX + -50 && x < destinoX + 50 && y > destinoY - 50 && destinoY < destinoY + 50) {
          animando = false;
        }

        if (x > destinoX + 50) {
          x -= 50;
        } else if (x < destinoX - 50) {
          x += 50;
        } else {
          x = destinoX;
        }
        if (y > destinoY + 50) {
          y -= 50;
        } else if (y < destinoY - 50) {
          y += 50;
        } else {
          y = destinoY;
        }
      }
    }

    if (x < width / 2 && y < height / 2) {

      fill(0);
      textSize(20);
      textAlign(CENTER);
      text("*Envenenar*", x + ancho/2, y - 10);
      if (agarrado == false) {
        if (fecha.dia == personaje.liderDia && personajesAtendidos == personaje.liderFila) {
          mostrarVeneno = false;
          segundaMisionGobierno = true;
          arma.mostrarArma = false;
          primerMisionOrganizacion = false;
          segundaMisionOrganizacion = false;
        }else{
          //vas en cana por envenenar a un civil
          mostrarVeneno = false;
        }
      }
    }
  }
}
