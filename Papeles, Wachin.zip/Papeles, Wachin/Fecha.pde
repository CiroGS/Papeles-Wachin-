class Fecha {

  int anio, mes, dia, hora;

  int maxIngresantes;

  Fecha() {
    anio = 2020;
    mes = 5;
    dia = 5;
    hora = 7;
  }

  void cambiaDia() {
    dinero.cobrar();
    dinero.dineroDescontado = 0;

    verificacion.multaTot = 0;

    dia += 1;
    manual.reiniciar();
    verificacion.penalizacionDia = 0;
  }

  void mostrar() {
    fill(0);
    textSize(20);
    textAlign(LEFT, TOP);
    text(dia + "/" + mes + "/" + anio, width / 200, height / 50);

    text("Ingresantes atendidos hoy: " + personajesAtendidos, width / 200, height / 50 + 25);
  }

  void chequearDia() {
    if (dia >= 1 && dia <3) {
      maxIngresantes = 3;
    }
    if (dia > 3 && dia < 7) {
      maxIngresantes = 3;
    }
    if(dia >=7){
      maxIngresantes = 3;
    }


    if (dia == 11) {
      estado = 5;
      comprobarFinal();
    }
  }
}
