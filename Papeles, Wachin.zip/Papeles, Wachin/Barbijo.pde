class Barbijo{ 
  
  int probabilidadBarbijo;
  
  boolean tieneBarbijo;
  
  String[] barbijos = {
    "barbijo0.png"
  };
  
  String barbijo;
  int barbijoIndice;
  
  Barbijo(){
    
  }
  void generarBarbijo(){
    probabilidadBarbijo = int(random(3));
    if(probabilidadBarbijo == 0){
      tieneBarbijo = false;
      if(personaje.extranjero){pasaporte.estado = false;}else{dni.estado = false;}
    }else{
      tieneBarbijo = true;
      barbijoIndice = int(random(barbijos.length));
      barbijo = barbijos[barbijoIndice];
      imgBarbijo = loadImage(barbijo);
    }
  }
  
  void mostrar(){
    if(tieneBarbijo){
      imgBarbijo.resize(anchoCara * 4, largoCara * 4);
      image(imgBarbijo, personaje.x, personaje.y);
    }
  }
  
}
