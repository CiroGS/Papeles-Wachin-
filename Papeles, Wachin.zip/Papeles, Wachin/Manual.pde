class Manual {
  int pagina;

  int x, y, ancho, largo, offsetX, offsetY, destinoX, destinoY, maxPagina, paginaPaises;

  boolean agarrado, animando;

  String mensaje, trabajosEsenciales, mensaje2, argentina2;

  String brasil, paraguay, bolivia, chile, uruguay, argentina;

  Manual() {

    ancho = 150;
    largo = 200;
    mensaje = "hola";
    destinoX = width / 3;
    destinoY = height - height / 6;
    x = destinoX;
    y = destinoY;
    pagina = 0;
  }

  void mostrar() {

    // Manual
    fill(100);
    rect(x, y, ancho, largo);
    fill(255);
    if (x <= width /2) {
      textSize(20);
      textAlign(CENTER, CENTER);
      text("Manual", x+ancho/2, y+largo/2);
    }

    if (x > width / 2) {
      mostrarDatos();
      square(x + 10, y + largo - 50, 40);
      square(x + ancho - 50, y + largo - 50, 40);
    }
  }

  void mousePressed() {
    if (mouseX >= x &&
      mouseX <= x + ancho &&
      mouseY >= y &&
      mouseY <= y + largo) {
      agarrado = true;
      offsetX = mouseX - x;
      offsetY = mouseY - y;
    }

    //Pasa pagina
    if (mouseX >= x + 10 && mouseX <= x + 50 &&
      mouseY >= y + largo - 50 && mouseY <= y + largo - 10) {

      // Colisión con el primer cuadrado
      if (pagina >= 1) {
        pagina--;
      }
    }

    if (mouseX >= x + ancho - 50 && mouseX <= x + ancho - 10 &&
      mouseY >= y + largo - 50 && mouseY <= y + largo - 10) {

      // Colisión con el segundo cuadrado
      if (pagina < maxPagina) {
        pagina++;
      }
    }
  }

  void mouseReleased() {
    agarrado = false;
  }

  void actualizar() {

    if (agarrado) {
      x = mouseX - offsetX;
      y = mouseY - offsetY;

      if (x > width / 2) {
        ancho = 450;
        largo = 600;
      } else {
        ancho = 150;
        largo = 200;
      }
    }

    if (x <= width / 2 && agarrado == false) {
      animando = true;

      if (x > destinoX + -50 && x < destinoX + 50 && y > destinoY - 50 && destinoY < destinoY + 50) {
        animando = false;
      }

      if (x > destinoX + 50) {
        x -= 50;
      } else if (x < destinoX - 50) {
        x += 50;
      } else {
        x = destinoX;
      }
      if (y > destinoY + 50) {
        y -= 50;
      } else if (y < destinoY - 50) {
        y += 50;
      } else {
        y = destinoY;
      }
    }
  }

  void reiniciar() {
    pagina = 0;
    x = destinoX;
    y = destinoY;
    ancho = 150;
    largo = 200;
  }

  void mostrarDatos() {
    for (int i = 0; i< permiso.trabajos.length; i++) {
      if (i == 0) {
        trabajosEsenciales = "\n"+permiso.trabajos[i];
        continue;
      }
      trabajosEsenciales = trabajosEsenciales + "\n" + permiso.trabajos[i];
    }

    if (fecha.dia == 1) {
      maxPagina = 2;
      paginaPaises = 1;
      if (pagina == 0) {
        mensaje = "Bienvenido a tu primer dia\nEl dia de hoy pueden pasar nacionales y extranjeros,\nexceptuando a las personas de nacionalidad\nBRASILERA\n\nDebera revisar los documentos, corroborar la fecha\nde vencimiento, la ciudad o provincia de emision y\nque el documento este en regla\n\nLos ingresantes deben presentar su documento de\nidentidad (pasaporte o DNI).\nEn caso de que no lo tenga preguntele\npor el mismo en la pestana de dialogo.";
      }
    }
    if (fecha.dia == 2) {
      maxPagina = 3;
      paginaPaises = 2;
      if (pagina == 0) {

        mensaje = "Felicitaciones por haber llegado a tu segundo dia.\nHoy podran ingresar todos los extranjeros con un\npermiso de circulacion.\nRevisa que los datos coincidan.";
      }
    }
    if (fecha.dia == 3) {
      maxPagina = 3;
      paginaPaises = 2;
      if (pagina == 0) {
        mensaje = "Se detecto un flujo mayor de inmigrantes en el pais.\nEl dia de hoy sigue vigente el permiso\nde circulacion para extranjeros.";
      }
    }
    if (fecha.dia == 4) {
      maxPagina = 3;
      paginaPaises = 2;
      if (pagina == 0) {
        mensaje = "Desde hoy el presidente Alverso decreto la\nobligatoriedad de llevar barbijo puesto.\nSi algun ingresante no lo lleva se debe indicar al\nmismo que se lo ponga\nen la pestana de dialogo.";
      }
    }
    for (int i = 0; i < personaje.ciudadesBrasil.length; i++) {
      if (i == 0) {
        brasil = "Brasil:";
      }
      brasil = brasil + "\n" + personaje.ciudadesBrasil[i];
    }
    for (int i = 0; i < personaje.ciudadesParaguay.length; i++) {
      if (i == 0) {
        paraguay = "\n\nParaguay:";
      }
      paraguay = paraguay + "\n" + personaje.ciudadesParaguay[i];
    }
    for (int i = 0; i < personaje.ciudadesBolivia.length; i++) {
      if (i == 0) {
        bolivia = "Bolivia:";
      }
      bolivia = bolivia + "\n" + personaje.ciudadesBolivia[i];
    }
    for (int i = 0; i < personaje.ciudadesChile.length; i++) {
      if (i == 0) {
        chile = "\n\nChile:";
      }
      chile = chile + "\n" + personaje.ciudadesChile[i];
    }
    for (int i = 0; i < personaje.ciudadesUruguay.length; i++) {
      if (i == 0) {
        uruguay = "\n\nUruguay:";
      }
      uruguay = uruguay + "\n" + personaje.ciudadesUruguay[i];
    }
    for (int i = 0; i < 15; i++) {
      if (i == 0) {
        argentina = "\n\nArgentina:";
      }
      argentina = argentina + "\n" + personaje.provinciasArgentina[i];
    }
    for (int i = 15; i < personaje.provinciasArgentina.length; i++) {
      if (i == 15) {
        argentina2 = personaje.provinciasArgentina[15];
      } else {

        argentina2 = argentina2 + "\n" + personaje.provinciasArgentina[i];
      }
    }
    if (pagina == paginaPaises) {
      mensaje = "Paises y ciudades:\n\n" + brasil + paraguay;
      mensaje2 = "\n\n" + bolivia + chile;
    } else if (pagina == paginaPaises + 1) {
      mensaje = "Paises y Ciudades:" + argentina;
      mensaje2 = argentina2 + "Uruguay:" + uruguay;
    } else {
      mensaje2="";
    }
    if (fecha.dia >= 2) {
      if (pagina == 1) {
        mensaje = "Trabajos esenciales: " + trabajosEsenciales + "\nCualquier permiso que no cumpla con\nlos requisitos sera rechazado.";
      }
    }



    textSize(20);
    fill(255);
    text(mensaje, x + ancho / 100, y + largo / 5);
    text(mensaje2, x + ancho / 2, y + largo / 5);
  }
}
