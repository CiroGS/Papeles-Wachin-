class Manual {
  int pagina;

  int x, y, ancho, largo, offsetX, offsetY, destinoX, destinoY;

  boolean agarrado, animando;

  String mensaje;

  Manual() {
    
    ancho = 150;
    largo = 250;
    mensaje = "hola";
    destinoX = width / 3;
    destinoY = height - height / 7;
    x = destinoX;
    y = destinoY;
    
  }

  void mostrar() {

    // Manual
    fill(100);
    rect(x, y, ancho, largo);
    fill(255);
    if (x <= width /2) {
      textSize(20);
      text("Manual", x+ancho/4, y+largo/2);
    }

    if (x > width / 2) {
      mostrarDatos();
      square(x + 10, y + largo - 50, 40);
      square(x + ancho - 50, y + largo - 50, 40);
    }
  }

  void mousePressed() {
    if (mouseX >= x &&
      mouseX <= x + ancho &&
      mouseY >= y &&
      mouseY <= y + largo) {
      agarrado = true;
      offsetX = mouseX - x;
      offsetY = mouseY - y;
    }
  }

  void mouseReleased() {
    agarrado = false;
  }

  void actualizar() {

    if (agarrado) {
      x = mouseX - offsetX;
      y = mouseY - offsetY;

      if (x > width / 2) {
        ancho = 450;
        largo = 750;
      } else {
        ancho = 150;
        largo = 250;
      }
    }

    if (x <= width / 2 && agarrado == false) {
      animando = true;
      
      if(x > destinoX + -50 && x < destinoX + 50 && y > destinoY - 50 && destinoY < destinoY + 50){
        animando = false;
      }

      if (x > destinoX + 50) {
        x -= 50;
      } else if (x < destinoX - 50) {
        x += 50;
      } else {
        x = destinoX;
      }
      if (y > destinoY + 50) {
        y -= 50;
      } else if (y < destinoY - 50) {
        y += 50;
      } else {
        y = destinoY;
      }
    }
  }

  void mostrarDatos() {
    if (fecha.dia == 1) {
      if (pagina == 0) {
        mensaje = "Bienvenido a tu primer dia\nEl dia de hoy pueden pasar nacionales y extranjeros";
      }
    }


    textSize(20);
    fill(255);
    text(mensaje, x + ancho / 100, y + largo / 5);
  }
}
