class DNI {

  boolean agarrado, tieneDNI, DNITrucho, DNIGenerado;
  int largo, ancho;

  int numero, emision, vencimiento;

  int offsetX, offsetY;

  int x, y, destinoX, destinoY; // del pasaporte

  String nombre, nacionalidad, provincia, apellido;

  boolean vencido, estado, provinciaFalsificada, fotoFalsa, muestraDNI, animando;
  int vencidoNum, provinciaNum;

  int probabilidadFalso, tieneDNINum;

  int indicePelo, indiceCara;
  PImage caraDNI, peloDNI;

  boolean DNIDevuelto;


  String caraPersonaje, peloPersonaje;

  //Provincias mal escritas
  String[] provinciasMalEscritas = {
    "Bunos Aires",
    "Catamarcca",
    "Chacco",
    "Chubutt",
    "Cordova",
    "Corrientess",
    "Entre Rioss",
    "Formoza",
    "Jujuyy",
    "La Pampaa",
    "La Riojaa",
    "Mendozza",
    "Misioness",
    "Neuquenn",
    "Rio Negrro",
    "Saltta",
    "San Juaan",
    "San Luiss",
    "Santa Cruzz",
    "Santa Fee",
    "Santiago del Esteroo",
    "Tierra del Fueggo",
    "Tucumann",
    "CABAA"
  };

  DNI() {

    destinoX = width/150;
    destinoY = height - height / 3;
  }

  void generarDNI() {

    DNITrucho = false;
    x = width / 150;
    y = height - height / 3;
    ancho = 150;
    largo = 100;
    numero = int(random(10000000, 99999999));
    vencimiento = int(random(2021, 2040));
    estado = true;
    vencido = false;
    provinciaFalsificada = false;
    caraPersonaje = personaje.caraPersonaje;
    peloPersonaje = personaje.peloPersonaje;

    //Probabilidad de que el dni sea falso
    if (personaje.pasaSiOSi) {
      probabilidadFalso = 142;
    } else {
      probabilidadFalso = int(random(10));
    }
    if (personaje.noPasa) {
      estado = false;
    }
    if (probabilidadFalso == 0) {
      estado = false;
      DNITrucho = true;
      probabilidadFalso = int(random(3));
      //Provincia
      if (probabilidadFalso == 0) {
        estado = false;
        provinciaFalsificada = true;
        provincia = provinciasMalEscritas[int(random(24))];
      }

      //vencimiento
      vencidoNum = int(random(4));
      if (probabilidadFalso == 1) {
        vencido = true;
        estado = false;
        vencimiento = int(random(2018, 2019));
      }

      if (probabilidadFalso == 2) {
        estado = false;
        fotoFalsa = true;
        do {
          indicePelo = int(random(personaje.pelos.length));
          peloPersonaje = personaje.pelos[indicePelo];
        } while (indicePelo == personaje.indicePelo);
        do {
          indiceCara = int(random(personaje.caras.length));
          caraPersonaje = personaje.caras[indiceCara];
        } while (indiceCara == personaje.indiceCara);
      }
    }
    tieneDNINum = int(random(10));
    if (personaje.pasaSiOSi) {
      tieneDNINum = 10;
    }
    if (personaje.noPasa) {
      tieneDNINum = 10;
    }
    if (tieneDNINum == 0) {
      tieneDNI = false;
      estado = false;
    } else if (tieneDNINum == 1) {
      tieneDNI = true;
      muestraDNI = false;
      estado = false;
    } else {
      tieneDNI = true;
      muestraDNI = true;
    }
    emision = vencimiento - int(random(1, 6));
    if (emision >2020) {
      emision = 2020;
    }
  }

  void mostrar() {

    // DNI
    fill(100);
    rect(x, y, ancho, largo);
    fill(255);
    if (x <= width /2) {
      textSize(20);
      text("DNI", x+ancho/4, y+largo/2);
    }

    if (x > width / 2) {
      mostrarDatos();
    }
  }

  void mousePressed() {
    if (mouseX >= x &&
      mouseX <= x + ancho &&
      mouseY >= y &&
      mouseY <= y + largo) {
      agarrado = true;
      offsetX = mouseX - x;
      offsetY = mouseY - y;
    }
  }

  void mouseReleased() {
    agarrado = false;
  }

  void actualizar() {
    if (agarrado) {
      x = mouseX - offsetX;
      y = mouseY - offsetY;

      if (x>width/2) {
        ancho = 450;
        largo = 300;
      } else {
        ancho = 150;
        largo = 100;
      }
    }

    if (x <= width / 2 && agarrado == false) {
      animando = true;

      if (x > destinoX + -50 && x < destinoX + 50 && y > destinoY - 50 && destinoY < destinoY + 50) {
        animando = false;
      }

      if (x > destinoX + 50) {
        x -= 50;
      } else if (x < destinoX - 50) {
        x += 50;
      } else {
        x = destinoX;
      }
      if (y > destinoY + 50) {
        y -= 50;
      } else if (y < destinoY - 50) {
        y += 50;
      } else {
        y = destinoY;
      }
    }

    if (x < width / 2 && y < height / 2) {
      fill(0);
      textSize(20);
      textAlign(CENTER);
      text("*DEVOLVER*", x + ancho/2, y - 10);

      if (agarrado == false) {
        muestraDNI = false;
        DNIDevuelto = true;
      }
    }
  }


  void mostrarDatos() {


    textAlign(LEFT, TOP);

    //Imagen DNI:



    caraDNI = loadImage(caraPersonaje);
    peloDNI = loadImage(peloPersonaje);

    caraDNI.resize(80, 100);
    image(caraDNI, x + 290, y + 50);
    if (personaje.peloLargo) {
      peloDNI.resize(90, 90);
      image(peloDNI, x+285, y + 30);
    } else {
      peloDNI.resize(90, 30);
      image(peloDNI, x+285, y + 20);
    }
    

    fill(255);

    textSize(24);
    text("DNI", x + 20, y + 35);

    textSize(18);

    if (nombre !=null) {
      text("Nombre:", x + 20, y + 80);
      text(nombre, x + 130, y + 80);
    }

    if (apellido != null) {
      text("Apellido:", x + 20, y + 110);
      text(apellido, x + 130, y + 110);
    }

    if (nacionalidad != null) {
      text("Nacionalidad:", x + 20, y + 140);
      text(nacionalidad, x + 160, y + 140);
    }

    if (provincia != null) {
      text("Provincia:", x + 20, y + 170);
      text(provincia, x + 130, y + 170);
    }

    text("Número:", x + 20, y + 200);
    text(numero, x + 130, y + 200);

    text("Emisión:", x + 20, y + 230);
    text(emision, x + 130, y + 230);

    text("Vencimiento:", x + 20, y + 260);
    text(vencimiento, x + 160, y + 260);
  }
}
