class DNI{

  boolean agarrado;
  int largo, ancho;
  
  int numero, emision, vencimiento;
  
  float offsetX, offsetY;

  float x, y; //posiscion del pasaporte
  
  String nombre, nacionalidad, provincia, apellido;
  
  boolean vencido, estado, provinciaFalsificada;
  int vencidoNum, provinciaNum;


//Provincias mal escritas
  String[] provinciasMalEscritas = {
  "Bunos Aires",
  "Catamarcca",
  "Chacco",
  "Chubutt",
  "Cordova",
  "Corrientess",
  "Entre Rioss",
  "Formoza",
  "Jujuyy",
  "La Pampaa",
  "La Riojaa",
  "Mendozza",
  "Misioness",
  "Neuquenn",
  "Rio Negrro",
  "Saltta",
  "San Juaan",
  "San Luiss",
  "Santa Cruzz",
  "Santa Fee",
  "Santiago del Esteroo",
  "Tierra del Fueggo",
  "Tucumann",
  "CABAA"
};

  DNI() {
  }
  
  void generarDNI(){
    x = width / 150;
    y = height - height / 3;
    ancho = 150;
    largo = 100;
    numero = int(random(10000000, 99999999));
    estado = true;
    vencido = false;
    provinciaFalsificada = false;
    
    //Provincia
    provinciaNum = int(random(5));
    if(provinciaNum == 1){
      estado = false;
      provinciaFalsificada = true;
      provincia = provinciasMalEscritas[int(random(24))];
    }
  
  //vencimiento
    vencidoNum = int(random(4));
    if(vencidoNum == 1){
      vencido = true;
      estado = false;
      vencimiento = int(random(2018, 2019));
    } else{
      vencido = false;
      vencimiento = int(random(2021, 2040));
    }
    emision = vencimiento - int(random(1, 6));
    if(emision >2020){emision = 2020;}
  }
  
  void mostrar() {

    // DNI
    fill(100);
    rect(x, y, ancho, largo);
    fill(255);
    if(x <= width /2){
      textSize(20);
      text("DNI", x+ancho/4, y+largo/2);
    }
    
    if (x > width / 2){
      mostrarDatos();
    }
  }
  
  void mousePressed(){
    if (mouseX >= x &&
        mouseX <= x + ancho &&
        mouseY >= y &&
        mouseY <= y + largo) {
          agarrado = true;
          offsetX = mouseX - x;
          offsetY = mouseY - y;
  }
  }
  
  void mouseReleased(){
    agarrado = false;
  }
  
  void actualizar(){
    if(agarrado){
      x = mouseX - offsetX;
      y = mouseY - offsetY;
      
      if(x>width/2){
        ancho = 450;
        largo = 300;
      } else {
        ancho = 150;
        largo = 100;
      }
    }
  }
  
  void mostrarDatos() {

    //Imagen DNI:
    
    imgCara.resize(80, 100);
    image(imgCara, x + 290, y + 50);
    imgPelo.resize(90, 30);
    image(imgPelo, x+285, y + 20);
    
    fill(255);
  
    textSize(24);
    text("DNI", x + 20, y + 35);
  
    textSize(18);
  
    if(nombre !=null){
      text("Nombre:", x + 20, y + 80);
      text(nombre, x + 130, y + 80);
    }
  
    if(apellido != null){
      text("Apellido:", x + 20, y + 110);
      text(apellido, x + 130, y + 110);
    }
  
    if(nacionalidad != null){
      text("Nacionalidad:", x + 20, y + 140);
      text(nacionalidad, x + 160, y + 140);
    }
  
    if(provincia != null){
      text("Provincia:", x + 20, y + 170);
      text(provincia, x + 130, y + 170);
    }
  
    text("Número:", x + 20, y + 200);
    text(numero, x + 130, y + 200);
  
    text("Emisión:", x + 20, y + 230);
    text(emision, x + 130, y + 230);
  
    text("Vencimiento:", x + 20, y + 260);
    text(vencimiento, x + 160, y + 260);
  }
}
