class Dialogo {

  int x, y, anchoBtn, altoBtn, anchoOpc, altoOpc, i;
  boolean desplegarOpciones, dialogo;

  String dialogoPersonaje;
  int tiempoDialogo;


  Dialogo() {
    anchoBtn = 50;
    altoBtn = 70;
    anchoOpc = width / 2 - width / 5;
    altoOpc = height - height / 3;
    dialogoPersonaje = "Hola";
  }

  void mostrar() {
    if (dialogo) {


      if (millis() - tiempoDialogo < 3000) {

        fill(0);
        textSize(25);
        textAlign(TOP, LEFT);

        text(
          dialogoPersonaje,
          width / 3,
          height / 8
          );
      } else {

        dialogo = false;
      }
    }

    // Botón de diálogo
    fill(255);
    rect(width / 5, height - height / 10, anchoBtn, altoBtn);

    textAlign(TOP, CENTER);
    textSize(20);
    text("Dialogo", width / 5 - 5, height - height / 9 - height / 100);

    if (desplegarOpciones) {

      // Rectángulo principal del diálogo
      rect(width - width / 4 - width / 7,
        height / 4,
        anchoOpc,
        altoOpc);

      // OPCIÓN 1
      fill(128);
      rect(width - width / 4 - width / 7 + 20,
        height / 4 + 30,
        anchoOpc - 40,
        50);

      fill(0);

      text("Sacate el barbijo gil",
        width - width / 4 - width / 7 + 30,
        height / 4 + 40);


      // OPCIÓN 2
      fill(128);
      rect(width - width / 4 - width / 7 + 20,
        height / 4 + 100,
        anchoOpc - 40,
        50);

      fill(0);

      text("Dame el Pasaporte",
        width - width / 4 - width / 7 + 30,
        height / 4 + 110);


      // OPCIÓN 3
      fill(128);
      rect(width - width / 4 - width / 7 + 20,
        height / 4 + 170,
        anchoOpc - 40,
        50);

      fill(0);

      text("Dame el DNI",
        width - width / 4 - width / 7 + 30,
        height / 4 + 180);


      // OPCIÓN 4
      fill(128);
      rect(width - width / 4 - width / 7 + 20,
        height / 4 + 240,
        anchoOpc - 40,
        50);

      fill(0);

      text("Y el barbijo?",
        width - width / 4 - width / 7 + 30,
        height / 4 + 250);
    }
  }


  void mousePressed() {

    // BOTÓN DE DIÁLOGO
    if (mouseX > width / 5 &&
      mouseX < width / 5 + anchoBtn &&
      mouseY > height - height / 10 &&
      mouseY < height - height / 10 + altoBtn) {

      i++;

      if (i % 2 == 1) {
        desplegarOpciones = true;
      } else {
        desplegarOpciones = false;
      }
    }


    // Las opciones solamente funcionan cuando están desplegadas
    if (desplegarOpciones) {


      // OPCIÓN 1 sacate el barbijo
      if (mouseX >= width - width / 4 - width / 7 + 20 &&
        mouseX <= width - width / 4 - width / 7 + 20 + anchoOpc - 40 &&
        mouseY >= height / 4 + 30 &&
        mouseY <= height / 4 + 30 + 50) {
        tiempoDialogo = millis();
        dialogo = true;
      }


      // OPCIÓN 2
      else if (mouseX >= width - width / 4 - width / 7 + 20 &&
        mouseX <= width - width / 4 - width / 7 + 20 + anchoOpc - 40 &&
        mouseY >= height / 4 + 100 &&
        mouseY <= height / 4 + 100 + 50) {
        tiempoDialogo = millis();
        dialogo = true;
      }


      // OPCIÓN 3
      else if (mouseX >= width - width / 4 - width / 7 + 20 &&
        mouseX <= width - width / 4 - width / 7 + 20 + anchoOpc - 40 &&
        mouseY >= height / 4 + 170 &&
        mouseY <= height / 4 + 170 + 50) {
        tiempoDialogo = millis();
        dialogo = true;

        println("Opción 3");
      }


      // OPCIÓN 4
      else if (mouseX >= width - width / 4 - width / 7 + 20 &&
        mouseX <= width - width / 4 - width / 7 + 20 + anchoOpc - 40 &&
        mouseY >= height / 4 + 240 &&
        mouseY <= height / 4 + 240 + 50) {
        tiempoDialogo = millis();
        dialogo = true;
        if (barbijo.barbijoGenerado) {
          if (barbijo.tieneBarbijo) {
            dialogoPersonaje = "Lo tengo puesto imb#cil";
          } else {
            dialogoPersonaje = "¿Hace falta?";
          }
        } else {
          dialogoPersonaje = "Eeh, no lo tengo";
        }

        println("Opción 4");
      }
    }
  }
}
