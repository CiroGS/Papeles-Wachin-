class Personaje {

  float x, y;
  int nacionalidadNum, pais; //0 Argentina - 1 Brasil - 2 Paraguay - 3 Bolivia - 4 Chile - 5 Uruguay
  boolean extranjero, genero; //extranjero 0 es Argentino/a - 1 es Extranjero // genero 0 es masculino 1 es femenino // verificacion 0 si no puede pasar 1 si puede pasar

  String nombre;
  String ciudad;
  String provincia;
  String nacionalidad;
  String apellido;

  int faseAnimacion;
  int tiempoFase;
  
  int indicePelo, indiceCara;

  int nombreNum, apellidoNum;

  int estadoPasaporte, estadoDNI; //si es 0 esta mal

  boolean animacionTerminada, permisoMostrado;

  String[] nombres = { //10 nombres masculinos (0 al 9) y 10 femeninos (10 al 19)
    "Juan",
    "Pedro",
    "Lucas",
    "Mateo",
    "Santiago",
    "Martín",
    "Nicolás",
    "Tomás",
    "Facundo",
    "Franco",
    "Sofía",
    "Valentina",
    "Camila",
    "Martina",
    "Julieta",
    "Agustina",
    "Lucía",
    "Micaela",
    "Carolina",
    "Florencia"
  };
  String[] apellidos = {
    "Gonzalez",
    "Rodriguez",
    "Fernandez",
    "Lopez",
    "Martinez",
    "Perez",
    "Garcia",
    "Sanchez",
    "Romero",
    "Diaz",
    "Torres",
    "Alvarez",
    "Ruiz",
    "Sosa",
    "Acosta",
    "Benitez",
    "Medina",
    "Herrera",
    "Suarez",
    "Rojas"
  };

  String[] ciudadesBrasil = { //1
    "Brasilia",
    "Rio de Janeiro",
    "Sao Paulo",
    "Florianopolis",
    "Salvador",
    "Belo Horizonte"
  };

  String[] ciudadesParaguay = { //2
    "Asuncion",
    "Ciudad del Este",
    "Encarnacion",
    "Luque",
    "San Lorenzo",
    "Pedro Juan Caballero"
  };

  String[] ciudadesBolivia = { //3
    "La Paz",
    "Santa Cruz de la Sierra",
    "Cochabamba",
    "Sucre",
    "Oruro",
    "Potosi"
  };

  String[] ciudadesChile = { //4
    "Santiago",
    "Valparaiso",
    "Concepcion",
    "Antofagasta",
    "Temuco",
    "Puerto Montt"
  };

  String[] ciudadesUruguay = { //5
    "Montevideo",
    "Salto",
    "Paysandu",
    "Maldonado",
    "Rivera",
    "Colonia del Sacramento"
  };

  String[] provinciasArgentina = {
    "Buenos Aires",
    "Catamarca",
    "Chaco",
    "Chubut",
    "Cordoba",
    "Corrientes",
    "Entre Rios",
    "Formosa",
    "Jujuy",
    "La Pampa",
    "La Rioja",
    "Mendoza",
    "Misiones",
    "Neuquen",
    "Rio Negro",
    "Salta",
    "San Juan",
    "San Luis",
    "Santa Cruz",
    "Santa Fe",
    "Santiago del Estero",
    "Tierra del Fuego",
    "Tucuman",
    "CABA"
  };



  Personaje() {
  }

  void mostrar() {

    imgCara = loadImage(caraPersonaje);
    imgCara.resize(anchoCara * 4, largoCara * 4);
    image(imgCara, x, y);

    imgPelo = loadImage(peloPersonaje);
    imgPelo.resize(anchoPelo * 4, largoPelo * 4);
    image(imgPelo, x - anchoPelo/4, y - largoPelo*4);
  }


  void animacion() {

    // FASE 0: el personaje se acerca
    if (faseAnimacion == 0) {

      if (x < width / 6) {
        x += 20;
      } else {
        faseAnimacion = 1;
        tiempoFase = millis();
      }
    }


    // FASE 1: pedir los documentos
    else if (faseAnimacion == 1) {

      fill(0);
      textSize(25);
      text(
        "Papeles, wachin!",
        width / 3,
        height / 8
        );

      if (millis() - tiempoFase >= 750) {
        faseAnimacion = 2;
        tiempoFase = millis();
      }
    }


    // FASE 2: entregar los documentos
    else if (faseAnimacion == 2) {

      fill(0);
      textSize(25);
      text(
        "Toma, boton",
        width / 3,
        height / 8
        );

      if (millis() - tiempoFase >= 750) {
        faseAnimacion = 3;
        tiempoFase = millis();
      }
    }


    // FASE 3: termina la animación
    else if (faseAnimacion == 3) {

      animacionTerminada = true;
    }
  }

  void crearPersonaje() {

    x = -100;
    y = height / 10;
    animacionTerminada = false;
    faseAnimacion = 0;
    permisoMostrado = false;


    crearApariencia();

    //nacionalidad:
    nacionalidadNum = int(random(5));
    //__________________________
    //IFS CUANDO HAY ALGO NUEVO
    //__________________________
    if (fecha.dia == 2 && personajesAtendidos == 0) {
      nacionalidadNum = 0;
    } //Hace que se genere el permiso el primer dia que se puede
    if (fecha.dia >= 3) { // A partir del dia 3 hay mas extranjeros
      nacionalidadNum = int(random(3));
    }
    println("Día: " + fecha.dia + 
        " | Personajes atendidos: " + personajesAtendidos + 
        " | Nacionalidad: " + nacionalidadNum);



    if (nacionalidadNum == 0) {
      extranjero = true;
    } else {
      extranjero = false;
    }
    if (extranjero == true) {
      pais = int(random(1, 6));
    } else {
      pais = 0;
    }

    //ciudad de nacimiento
    if (pais == 1) {
      ciudad = ciudadesBrasil[int(random(6))];
      nacionalidad = "Brasil";
    }
    if (pais == 2) {
      ciudad = ciudadesParaguay[int(random(6))];
      nacionalidad = "Paraguay";
    }
    if (pais == 3) {
      ciudad = ciudadesBolivia[int(random(6))];
      nacionalidad = "Bolivia";
    }
    if (pais == 4) {
      ciudad = ciudadesChile[int(random(6))];
      nacionalidad = "Chile";
    }
    if (pais == 5) {
      ciudad = ciudadesUruguay[int(random(6))];
      nacionalidad = "Uruguay";
    }

    if (pais == 0) {
      nacionalidad = "Argentina";
      provincia = provinciasArgentina[int(random(24))];
    }


    //genero y nombre
    int generoInt = int(random(2));
    if (generoInt == 1) {
      genero = true;
      nombreNum = int(random(0, 10));
      nombre = nombres[nombreNum];
    } else {
      genero=false;
      nombreNum = int(random(10, 20));
      nombre = nombres[nombreNum];
    }

    apellidoNum = int(random(20));
    apellido = apellidos[apellidoNum];




    if (extranjero) {
      generarPasaporte();
      if (fecha.dia >= 2) {
        generarPermiso();
      }
    } else {
      generarDNI();
      if (fecha.dia >= 4) {
        generarPermiso();
      }
    }
  }

  void generarPermiso() {
    permisoMostrado = true;
    permiso.nombre = nombre;
    permiso.nacionalidad = nacionalidad;
    permiso.apellido = apellido;
    
    if (extranjero) {
      permiso.numero = pasaporte.numero;
    } else {
      permiso.numero = dni.numero;
    }

    permiso.generarPermiso();
  }

  void generarPasaporte() {
    pasaporte.nombre = nombre;
    pasaporte.nacionalidad = nacionalidad;
    pasaporte.ciudad = ciudad;
    pasaporte.apellido = apellido;

    pasaporte.generarPasaporte();
  }


  void generarDNI() {
    dni.nombre = nombre;
    dni.nacionalidad = nacionalidad;
    dni.provincia = provincia;
    dni.apellido = apellido;

    dni.generarDNI();
  }

  void datosdebug() {
    println("----------------------");
    println("Pais: " + pais);
    println("Extranjero: " + extranjero);
    println("Genero: " + genero);
    println("Nombre: " + nombre);
    println("Ciudad: " + ciudad);
    println("Provincia: " + provincia);
  }


  void nuevoPersonaje() {

    personaje = new Personaje();
    personaje.crearPersonaje();
  }


  String[] caras = { //sprites de las caras
    "cara0.png",
    "cara1.png"
  };

  String[] pelos = {
    "pelo0.png",
    "pelo1.png"
  };

  String peloPersonaje;
  String caraPersonaje;

  void crearApariencia() { // Crea el Pelo, altura, peso, y cara del personaje
    indicePelo = int(random(caras.length));
    indiceCara = int(random(pelos.length));
    caraPersonaje = caras[indiceCara];
    peloPersonaje = pelos[indicePelo];
  }
}
