class FinalDia {

  boolean mostrandoCuota;
  int tiempoCuota;
  String mensaje;

  void pantalla() {

    background(0);

    fill(255);
    textAlign(CENTER, CENTER);

    textSize(50);
    text("DÍA " + fecha.dia + " COMPLETADO",
      width / 2, height / 4);

    textSize(30);
    if(dinero.dineroDescontado> 0){
      text(
        "Ingresantes atendidos: " + personajesAtendidos + "\n\n" +
        "Errores: " + verificacion.penalizacionDia + " (-" + dinero.dineroDescontado + "$)",
        width / 2,
        height / 2
        );
    } else {
      text(
        "Ingresantes atendidos: " + personajesAtendidos + "\n\n" +
        "Sin errores. Buen trabajo, wachin!",
        width / 2,
        height / 2
        );
    }

    textSize(20);
    fill(255);
    rect(width / 2 - 120, height - height / 10 - 20, 240, 40);

    fill(0);
    text(
      "Hacé clic para continuar",
      width / 2,
      height - height / 10
      );

    dinero.mostrar();

    cuotaPendiente();
  }


  void mousePressed() {

    if (mouseX >= width / 2 - 120 &&
      mouseX <= width / 2 + 120 &&
      mouseY >= height - height / 10 - 20 &&
      mouseY <= height - height / 10 + 20) {

      if (dinero.cuotaPagada) {

        fecha.cambiaDia();
        personaje.nuevoPersonaje();
        dinero.pagar();
        estado = 2;
        dinero.i = 0;
        dinero.colCuadrado = color(255, 0, 0);
        dinero.cuotaPagada = false;

      } else {

        mostrandoCuota = true;
        tiempoCuota = millis();
        mensaje = "Debe pagar la cuota para continuar";
      }
    }
  }


  void cuotaPendiente() {
    if (mostrandoCuota) {

      fill(255, 0, 0);
      textSize(25);
      textAlign(CENTER, CENTER);

      text(
        mensaje,
        width / 2,
        height / 2
        );

      if (millis() - tiempoCuota >= 1000) {
        mostrandoCuota = false;
      }
    }
  }
}
