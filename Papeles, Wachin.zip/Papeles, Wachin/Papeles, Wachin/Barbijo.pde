class Barbijo{ 
  
  int probabilidadBarbijo;
  
  boolean tieneBarbijo;
  boolean barbijoGenerado;
  
  String[] barbijos = {
    "barbijo0.png",
    "barbijo1.png",
    "barbijo2.png",
    "barbijo3.png",
    "barbijo4.png",
    "barbijo5.png",
    "barbijo6.png",
    "barbijo7.png"
  };
  
  String barbijo;
  int barbijoIndice;
  
  Barbijo(){
    
  }
  void generarBarbijo(){
    barbijoGenerado = true;
    probabilidadBarbijo = int(random(3));
    if(probabilidadBarbijo == 0){
      tieneBarbijo = false;
      if(personaje.extranjero){pasaporte.estado = false;}else{dni.estado = false;}
    }else{
      tieneBarbijo = true;
      barbijoIndice = int(random(barbijos.length));
      barbijo = barbijos[barbijoIndice];
      imgBarbijo = loadImage(barbijo);
    }
  }
  void deshabilitarBarbijo(){
    tieneBarbijo = false;
  }
  
  void mostrar(){
    if(tieneBarbijo){
      imgBarbijo.resize(anchoCara * 4, largoCara * 4);
      image(imgBarbijo, personaje.x, personaje.y);
    }
  }
  
}
