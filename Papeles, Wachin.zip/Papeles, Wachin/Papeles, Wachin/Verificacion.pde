class Verificacion {

  int tiempoMensaje, penalizacionDia, penalizacionTot, multa, multaTot;
  boolean mostrandoMensaje;

  Verificacion() {
    mostrandoMensaje = false;
    
    multa = 50;
  }

  void verificarPasa() {
    
    if(personaje.extranjero){
      if(pasaporte.estado == false){
        penalizacion();
      }
    } else {
      if(dni.estado == false){
        penalizacion();
      }
    }
  }
  
  void verificarNoPasa(){
    if(personaje.extranjero){
      if(pasaporte.estado){
        penalizacion();
      }
    } else {
      if(dni.estado){
        penalizacion();
      }
    }
  }

  void vencimientoPasa() {

    if (personaje.extranjero) {
      if (pasaporte.estado == false) {
        penalizacion();
      }
    } else {
      if(dni.estado == false){
        penalizacion();
      }
    }
  }
  
  void vencimientoNoPasa(){
    if (personaje.extranjero) {
      if (pasaporte.vencido) {
      } else { penalizacion();
      }

    } else {

      if (dni.vencido) {
      } else { penalizacion();
      }
    }
  }
  

  

  void penalizacion() {

    // Activar mensaje
    mostrandoMensaje = true;
    tiempoMensaje = millis();

    penalizacionDia++;
    penalizacionTot++;
    
    dinero.dinero -= multa;
    multaTot += multa;
    dinero.dineroDescontado = multaTot;
  }

  void mostrarPenalizacion() {

    if (mostrandoMensaje) {

      fill(255, 0, 0);
      textSize(30);
      text("Error", width - width / 6, height / 4);

      // Pasaron 2 segundos
      if (millis() - tiempoMensaje >= 2000) {
        mostrandoMensaje = false;
      }
    }
  }
}
