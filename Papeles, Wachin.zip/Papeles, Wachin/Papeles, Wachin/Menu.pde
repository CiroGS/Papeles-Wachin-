class Menu {

  void mostrar() {

    float escala = max(
      (float)width / fondo.width,
      (float)height / fondo.height
    );

    float ancho = fondo.width * escala;
    float alto = fondo.height * escala;

    float x = (width - ancho) / 2;
    float y = (height - alto) / 2;

    image(fondo, x, y, ancho, alto);


    // BOTONES

    fill(255);

    // SALIR
    rect(width/2 - 150, height * 0.85, 300, 70);

    // OPCIONES
    rect(width/2 - 150, height * 0.75, 300, 70);

    // JUGAR
    rect(width/2 - 150, height * 0.65, 300, 70);
  }
}
