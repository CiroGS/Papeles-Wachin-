class Permiso {

  int x, y, ancho, largo, offsetX, offsetY;

  boolean agarrado, estado, trabajoFalso, numeroFalso, nombreFalso;


  int numero, numeroNum, nombreNum, nombreIndice, apellidoIndice;

  String nombre, apellido, nacionalidad;

  int probabilidadFalso;

  int trabajoNum;
  String trabajo;

  String[] trabajos = {
    "Medico",
    "Enfermero",
    "Policia",
    "Repartidor",
    "Transportista"
  };

  String[] trabajosNoEsenciales = {
    "Ferretero",
    "Musico",
    "Peluquero",
    "Vendedor de cursos",
    "Repositor"
  };

  Permiso() {
  }

  void generarPermiso() {
    estado = true;
    numeroFalso = true;
    trabajoFalso = true;
    x = width / 10;
    y = height - height / 3;
    ancho = 100;
    largo = 130;
    trabajo = trabajos[int(random(5))];


    //Probabilidad de que sea falso:
    probabilidadFalso = int(random(5));
    if (probabilidadFalso == 0) {

      probabilidadFalso = int(random(3));
      //genera el trabajo
      if (probabilidadFalso == 0) {
        trabajo = trabajosNoEsenciales[int(random(5))];
        estado = false;
        if (personaje.extranjero) {
          pasaporte.estado = false;
        } else {
          dni.estado = false;
        }
        trabajoFalso = true;
      }

      //genera el numero falso si hay
      if (probabilidadFalso == 1) {
        if (personaje.extranjero) {
          pasaporte.estado = false;
        } else {
          dni.estado = false;
        }
        numeroFalso = true;
        numero = int(random(10000000, 99999999));
      }

      //Nombre o apellido falso
      if (probabilidadFalso == 2) {
        if (personaje.extranjero) {
          pasaporte.estado = false;
        } else {
          dni.estado = false;
        }
        nombreNum = int(random(10));
        if (nombreNum >=0 && nombreNum <=4) {

          do {
            nombreIndice = int(random(20));
          } while (nombreIndice == personaje.nombreNum);
          nombre = personaje.nombres[nombreIndice];
        }

        if (nombreNum >=5 && nombreNum <=9) {
          do {
            apellidoIndice = int(random(20));
          } while (apellidoIndice == personaje.apellidoNum);
          apellido = personaje.apellidos[apellidoIndice];
        }
      }
    }
  }

  void mostrar() {

    // Permiso
    fill(100);
    rect(x, y, ancho, largo);
    fill(255);
    if (x <= width /2) {
      textSize(20);
      text("PERMISO", x+ancho/4, y+largo/2);
    } else {
      mostrarDatos();
    }
  }


  void mousePressed() {
    if (mouseX >= x &&
      mouseX <= x + ancho &&
      mouseY >= y &&
      mouseY <= y + largo) {
      agarrado = true;
      offsetX = mouseX - x;
      offsetY = mouseY - y;
    }
  }

  void mouseReleased() {
    agarrado = false;
  }

  void actualizar() {
    if (agarrado) {
      x = mouseX - offsetX;
      y = mouseY - offsetY;

      if (x>width/2) {
        ancho = 300;
        largo = 390;
      } else {
        ancho = 100;
        largo = 130;
      }
    }
  }

  void mostrarDatos() {

    fill(255);

    textSize(24);
    text("Permiso de Ciculacion", x + 20, y + 35);

    textSize(18);

    text("Nombre:", x + 20, y + 80);
    text(nombre, x + 130, y + 80);

    text("Apellido:", x + 20, y + 110);
    text(apellido, x + 130, y + 110);

    text("Número:", x + 20, y + 140);
    text(numero, x + 130, y + 140);

    text("Trabajo:", x + 20, y + 170);
    text(trabajo, x + 130, y + 170);
  }
}
