PImage fondo;
PImage garita;
PImage imgCara;
PImage imgPelo;
PImage imgBarbijo;

Menu menu;
Juego juego;
Personaje personaje;
Pasaporte pasaporte;
DNI dni;
BotonPasa botonPasa;
BotonNoPasa botonNoPasa;
Verificacion verificacion;
Fecha fecha;
Cinematica cinematica;
FinalDia finaldia;
Dinero dinero;
Permiso permiso;
Barbijo barbijo;
Manual manual;
Dialogo dialogo;

int estado = 0;
int anchoCara = 30;
int largoCara = 35;
int anchoPelo = 34;
int largoPelo = 10;

int personajesAtendidos; //Cantidad de personajes que el jugador denego o aprobo para pasar
// 0 = menú
// 1 = juego
// 2 = Cinematica
// 3 = Game over
// 4 = Pantalla final del dia
// 5 = Final del juego


void setup() {

  fullScreen();


  fondo = loadImage("menu.png");
  garita = loadImage("garita.png");
  botonPasa = new BotonPasa();
  botonNoPasa = new BotonNoPasa();
  verificacion = new Verificacion();
  permiso = new Permiso();
  fecha = new Fecha();
  cinematica = new Cinematica();
  finaldia = new FinalDia();
  dinero = new Dinero();
  menu = new Menu();
  juego = new Juego();
  dni = new DNI();
  pasaporte = new Pasaporte();
  personaje = new Personaje();
  barbijo = new Barbijo();
  manual = new Manual();
  dialogo = new Dialogo();

  personaje.crearPersonaje();
  personaje.datosdebug();
}

void draw() {
  if (estado == 0) {
    menu.mostrar();
    textSize(30);
    text("version 0.4 ||", 20, height - 20);
  } else if (estado == 1) {
    juego.mostrar();
  } else if (estado == 2) {
    cinematica.mostrar();
  } else if (estado == 4) {
    finaldia.pantalla();
  }

  fecha.chequearDia();
}

void mouseReleased() {
  if (estado == 1) {
    pasaporte.mouseReleased();
    dni.mouseReleased();
    permiso.mouseReleased();
    manual.mouseReleased();
  }
}


void mousePressed() {
  if (estado == 0) {
    if (mouseX >= width / 2 - 150 && mouseX <= width / 2 + 150 && mouseY >= height * 0.65 && mouseY <= height * 0.65 + 70) {
      print("ja");
      estado = 2;
    }
  }
  if (estado == 1) {
    pasaporte.mousePressed();
    dni.mousePressed();
    botonPasa.mousePressed();
    botonNoPasa.mousePressed();
    permiso.mousePressed();
    manual.mousePressed();
    dialogo.mousePressed();
  }
  if (estado == 2) {
    cinematica.mousePressed();
  }

  if (estado == 4) {
    finaldia.mousePressed();
    dinero.mousePressed();
  }
}
