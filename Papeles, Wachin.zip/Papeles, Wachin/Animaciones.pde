class Animaciones {
  String dialogo;
  boolean animacionEnCurso, animacionTerminada, esperandoClic;

  int faseAnimacion, tiempoFase, numTarjeta;
  int faseAnimacion1;
  int tiempoFase1;

  boolean animacionEspia;

  Animaciones() {
    faseAnimacion = 0;
    faseAnimacion1 = 0;
    tiempoFase1 = millis();
  }

  void animacion() {
    animacionEnCurso = true;
    if (fecha.dia == personaje.liderDia && personajesAtendidos == personaje.liderFila && segundaMisionOrganizacion == false) {
      personaje.dialogoEspecial = false;
    }
    if (personaje.dialogoEspecial == false) {

      // FASE 0: el personaje se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
          tiempoFase = millis();
        }
      }


      // FASE 1: pedir los documentos
      else if (faseAnimacion == 1) {

        fill(0);
        textSize(25);
        dialogo ="Papeles, wachin!";
        text(dialogo,
          width / 3,
          height / 8
          );

        if (millis() - tiempoFase >= 750) {
          faseAnimacion = 2;
          tiempoFase = millis();
        }
      }


      // FASE 2: entregar los documentos
      else if (faseAnimacion == 2) {

        fill(0);
        textSize(25);
        dialogo = "Toma, boton";
        text(
          dialogo,
          width / 3,
          height / 8
          );

        if (millis() - tiempoFase >= 750) {
          faseAnimacion = 3;
          tiempoFase = millis();
        }
      }


      // FASE 3: termina la animación
      else if (faseAnimacion == 3) {

        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }
    if (animacionEspia == true) {
      if (faseAnimacion == 0) {

        fill(0);
        textSize(25);
        dialogo ="Gracias pa";
        text(dialogo,
          width / 3,
          height / 8
          );

        if (millis() - tiempoFase >= 750) {
          faseAnimacion = 1;
          tiempoFase = millis();
        }
      }


      // FASE 2: entregar los documentos
      else if (faseAnimacion == 1) {

        fill(0);
        textSize(25);
        dialogo = "Estamos en contacto";
        text(
          dialogo,
          width / 3,
          height / 8
          );

        if (millis() - tiempoFase >= 750) {
          faseAnimacion = 2;
          tiempoFase = millis();
        }
      }


      // FASE 3: termina la animación
      else if (faseAnimacion == 2) {

        animacionTerminada = true;
        animacionEnCurso = false;
        animacionEspia = false;
      }
    }
    if (fecha.dia == 1 && personajesAtendidos == 0) { // Inspector primer dia
      // FASE 0: el personaje se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
          tiempoFase = millis();
        }
      }

      // FASE 1
      else if (faseAnimacion == 1) {

        fill(0);
        textSize(25);
        dialogo = "Que onda papa, yo soy el inspector";
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 2;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 2
      else if (faseAnimacion == 2) {

        fill(0);
        textSize(25);
        dialogo = "Asi que si te mandas alguna es\nmi responsabilidad";
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 3;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 3
      else if (faseAnimacion == 3) {

        fill(0);
        textSize(25);
        dialogo = "Ahora lee el manual y cuando\nestes listo empeza a atender";
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 4;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 4: animación terminada
      else if (faseAnimacion == 4) {
        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }

    if (fecha.dia == personaje.anuelDia && personajesAtendidos == personaje.anuelFila) { // ANUEL AA
      // FASE 0: el personaje se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
          tiempoFase = millis();
        }
      }


      // FASE 1: pedir los documentos
      else if (faseAnimacion == 1) {

        fill(0);
        textSize(25);
        dialogo ="Anuel, SOS VOS!";
        textAlign(LEFT);
        text(dialogo,
          width / 3,
          height / 8
          );

        if (millis() - tiempoFase >= 750) {
          faseAnimacion = 2;
          tiempoFase = millis();
        }
      }


      // FASE 2: entregar los documentos
      else if (faseAnimacion == 2) {

        fill(0);
        textSize(25);
        dialogo = "Si papi.\nVolviendo del ignacio";
        textAlign(LEFT);
        text(
          dialogo,
          width / 3,
          height / 8
          );

        if (millis() - tiempoFase >= 750) {
          faseAnimacion = 3;
          tiempoFase = millis();
        }
      }


      // FASE 3: termina la animación
      else if (faseAnimacion == 3) {

        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }


    if (fecha.dia == personaje.javierMiguelDia1 && personajesAtendidos == personaje.javierMiguelFila1) {
      // FASE 0: el personaje se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
        }
      }

      // FASE 1
      else if (faseAnimacion == 1) {

        fill(0);
        textSize(25);
        dialogo = "Hola, soy el Javo";
        textAlign(LEFT);
        fill(148, 0, 211);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 2;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 2
      else if (faseAnimacion == 2) {

        fill(0);
        textSize(25);
        fill(148, 0, 211);
        textAlign(LEFT);
        dialogo = "Te dejo esta tarjetita.\nFijate vos nomas";

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 3;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 3
      else if (faseAnimacion == 3) {

        fill(0);
        textSize(25);
        fill(148, 0, 211);
        textAlign(LEFT);
        dialogo = "Somos la Organizacion";

        text(dialogo, width / 4, height / 8);

        //Da la tarjeta
        numTarjeta = 0;
        tarjeta.generarTarjeta(numTarjeta);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 4;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 4: animación terminada
      else if (faseAnimacion == 4) {
        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }

    //Marcos Lunas
    if (fecha.dia == personaje.marcosDia && personajesAtendidos == personaje.marcosFila) {

      // FASE 0: el personaje se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
        }
      }

      // FASE 1
      else if (faseAnimacion == 1) {

        fill(255, 0, 0);
        textSize(25);
        textAlign(LEFT);
        dialogo = "Que onda compa.\nNo me haces pasar?";
        fill(148, 0, 211);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 2;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 2
      else if (faseAnimacion == 2) {

        fill(0);
        textSize(25);
        fill(148, 0, 211);
        textAlign(LEFT);
        dialogo = "Yo conozco al javo,\nvo sabe";

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 3;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 3
      else if (faseAnimacion == 3) {

        fill(0);
        textSize(25);
        fill(148, 0, 211);
        textAlign(LEFT);
        dialogo = "Tengo unos pesos ademas ermano";

        text(dialogo, width / 4, height / 8);

        //Da la plata

        //plata.generarPlata(); (capaz ni lo hago)

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 4;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 4: animación terminada
      else if (faseAnimacion == 4) {
        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }
    if (fecha.dia == personaje.marcosDia && personajesAtendidos == personaje.marcosFila && tarjeta.tarjetaDevuelta) {
      faseAnimacion = 10;
      if (faseAnimacion == 10) {

        textSize(25);
        textAlign(LEFT);
        dialogo = "Ahhh vo sabe gato";
        fill(255, 0, 0);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 12;
          esperandoClic = true;
        }
        if (!mousePressed) {
          esperandoClic = false;
        }
      }
      if (faseAnimacion == 12) {
        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }


    //Javier Miguel segunda vez


    if (fecha.dia == personaje.javierMiguelDia2 && personajesAtendidos == personaje.javierMiguelFila2) {
      // FASE 0: el personaje se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
        }
      }

      // FASE 1
      else if (faseAnimacion == 1) {

        fill(0);
        textSize(25);
        if (primerMisionOrganizacion) {
          dialogo = "Bien papa, estamos agradecidos,\nesto es para vos"; // le da la tarjeta del narco
        } else {
          dialogo = "Flaco lo tenias que dejar pasar sos bobo.\nNo importa, ahora toma esto"; // le da la tarjeta del narco
        }
        textAlign(LEFT);
        fill(148, 0, 211);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 2;
          esperandoClic = true;
          numTarjeta = 1;
          tarjeta.generarTarjeta(numTarjeta);
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 2
      else if (faseAnimacion == 2) {

        fill(0);
        textSize(25);
        fill(148, 0, 211);
        textAlign(LEFT);
        dialogo = "Se la tenes que dar al pilchero.\nFijate que es asi morocho, siempre usa visera\n y anda drogado todo el tiempo";

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 3;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 3
      else if (faseAnimacion == 3) {

        fill(0);
        textSize(25);
        fill(148, 0, 211);
        textAlign(LEFT);
        dialogo = "Acordate porque lo va a querer uno del gobierno\ndel Alverso, si lo agarra ese cagamos";

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 4;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 4: animación terminada
      if (faseAnimacion == 4) {
        fill(0);
        textSize(25);
        fill(148, 0, 211);
        textAlign(LEFT);
        dialogo = "Mira que si no se lo das\nte va querer hacer cagar fuego.\nYo que vos no joderia";

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 5;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }
      if (faseAnimacion == 5) {
        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }

    //NARCO

    if (fecha.dia == personaje.narcoDia && personajesAtendidos == personaje.narcoFila) { //NARCO
      // FASE 0: el personaje se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
          tiempoFase = millis();
        }
      }

      // FASE 1
      else if (faseAnimacion == 1) {

        fill(255, 0, 0);
        textSize(25);
        dialogo = "Ameo, vos tenes algo que\nes mio";
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 2;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 2
      else if (faseAnimacion == 2) {

        fill(255, 0, 0);
        textSize(25);
        dialogo = "...";
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 3;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 3: animación terminada
      else if (faseAnimacion == 3) {
        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }

    if (fecha.dia == personaje.liderDia && personajesAtendidos == personaje.liderFila && segundaMisionOrganizacion == true) {
      // FASE 0: el personaje se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
          tiempoFase = millis();
        }
      }

      // FASE 1
      else if (faseAnimacion == 1) {

        fill(0, 0, 0);
        textSize(25);
        dialogo = "Soy Jefe, y como confiamos\nen vos, necesitamos que\nhagas una ultima cosa";
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 2;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 2
      else if (faseAnimacion == 2) {

        fill(0, 0, 0);
        textSize(25);
        dialogo = "Tenes que asesinar al inspector.\nToma.";
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 3;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
          arma.generarArma();
        }
      }

      // FASE 3: animación terminada
      else if (faseAnimacion == 3) {
        animacionTerminada = true;
        animacionEnCurso = false;

        //Mostrar arma
      }
    }

    //Segundo dia Inspector
    // Inspector - Dia 4
    if (fecha.dia == personaje.inspectorDia2 && personajesAtendidos == personaje.inspectorFila2) {

      animacionEnCurso = true;
      animacionTerminada = false;

      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
          tiempoFase = millis();
        }
      }

      if (faseAnimacion == 1) {
        fill(0);
        textAlign(LEFT);
        dialogo = "Buenas, ¿como viene todo por aca?\nEstuve revisando algunos de\nlos registros de estos ultimos dias.";
        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 2;
          esperandoClic = true;
        }
        if (!mousePressed) esperandoClic = false;
      } else if (faseAnimacion == 2) {
        fill(0);
        textAlign(LEFT);
        dialogo = "Hay algunas cosas que no me terminan de cerrar.\nPero bueno, son tus primeros\ndias no pasa nada.";
        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 3;
          esperandoClic = true;
        }
        if (!mousePressed) esperandoClic = false;
      } else if (faseAnimacion == 3) {
        fill(0);
        textAlign(LEFT);
        dialogo = "Lo que si voy a necesitar\nes que le des estos documentos\na jorge, es nuestro espia.";
        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 4;
          esperandoClic = true;
          documentos.generarDocumentos(0);
        }
        if (!mousePressed) esperandoClic = false;
      } else if (faseAnimacion == 4) {
        fill(0);
        textAlign(LEFT);
        dialogo = "Es rubiecito, bien palido.\nCuando lo veas te vas a dar cuenta.";
        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 5;
          esperandoClic = true;
        }
        if (!mousePressed) esperandoClic = false;
      } else if (faseAnimacion == 5) {
        fill(0);
        textAlign(LEFT);
        dialogo = "Pero quiero que estes mas atento.\nNo me gustaria descubrir que alguien esta\nhaciendo la vista gorda.";
        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 6;
          esperandoClic = true;
        }
        if (!mousePressed) esperandoClic = false;
      } else if (faseAnimacion == 6) {
        fill(0);
        textAlign(LEFT);
        dialogo = "Bueno, segui trabajando.\nVoy a estar vigilando.";
        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 7;
          esperandoClic = true;
        }
        if (!mousePressed) esperandoClic = false;
      } else if (faseAnimacion == 7) {
        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }


    // Ultimo dia Inspector
    if (fecha.dia == personaje.inspectorDiaUlt && personajesAtendidos == personaje.inspectorFilaUlt) {

      // FASE 0: el inspector se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
        }
      }

      // FASE 1
      else if (faseAnimacion == 1) {

        fill(0);
        textSize(25);
        textAlign(LEFT);

        dialogo = "Bueno, wachin... Llegamos al ultimo dia.";

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 2;
          esperandoClic = true;
        }

        if (!mousePressed) esperandoClic = false;
      }

      // FASE 2
      else if (faseAnimacion == 2) {

        fill(0);
        textSize(25);
        textAlign(LEFT);

        dialogo = "Pasaron muchas cosas desde que\nempezaste aca, ¿no?";

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 3;
          esperandoClic = true;
        }

        if (!mousePressed) esperandoClic = false;
      }

      // FASE 3
      else if (faseAnimacion == 3) {

        fill(0);
        textSize(25);
        textAlign(LEFT);

        dialogo = "El pais ya no es el mismo.\nY nosotros tampoco.";

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 4;
          esperandoClic = true;
        }

        if (!mousePressed) esperandoClic = false;
      }

      // FASE 4
      else if (faseAnimacion == 4) {

        fill(0);
        textSize(25);
        textAlign(LEFT);

        if (segundaMisionOrganizacion) {
          dialogo = "No se que te prometieron, wachin...\nPero espero que sepas lo que haces.";
        } else {
          dialogo = "Queria agradecerte por tu trabajo.\nEspero que hayas sabido elegir bien.";
        }

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 5;
          esperandoClic = true;
        }

        if (!mousePressed) esperandoClic = false;
      }

      // FASE 5: despedida
      else if (faseAnimacion == 5) {

        fill(0);
        textSize(25);
        textAlign(LEFT);

        dialogo = "Suerte, wachin.\nNos vemos... si es que nos vemos.";

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 6;
          esperandoClic = true;
        }

        if (!mousePressed) esperandoClic = false;
      }

      // FASE 6: termina
      else if (faseAnimacion == 6) {
        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }

    if (fecha.dia == personaje.espiaDia1 && personajesAtendidos == personaje.espiaFila1) { // Espia segundo dia
      // FASE 0: el personaje se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
          tiempoFase = millis();
        }
      }

      // FASE 1
      else if (faseAnimacion == 1) {

        fill(0);
        textSize(25);
        dialogo = "Tenemos al lider de ellos";
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 2;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 2
      else if (faseAnimacion == 2) {

        fill(0);
        textSize(25);
        dialogo = "Lo vas a tener que envenenar.\nYo no te dije nada pero\nestan organizando un golpe";
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 3;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 3
      else if (faseAnimacion == 3) {

        fill(0);
        textSize(25);
        dialogo = "Si no lo envenenas cagamos todos\nlos que estamos aca"; // le da el veneno
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 4;
          esperandoClic = true;
          veneno.generarVeneno();
          documentos.generarDocumentos(1);
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 4: animación terminada
      else if (faseAnimacion == 4) {
        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }

    if (fecha.dia == personaje.inspectorDia3 && personajesAtendidos == personaje.inspectorFila3) {
      // FASE 0: el personaje se acerca
      if (faseAnimacion == 0) {

        if (personaje.x < width / 6) {
          personaje.x += 20;
        } else {
          faseAnimacion = 1;
          tiempoFase = millis();
        }
      }

      // FASE 1
      else if (faseAnimacion == 1) {

        fill(0);
        textSize(25);
        if (segundaMisionGobierno) {
          dialogo = "Muy bien, estamos ahi nomas";
        } else {
          dialogo="Ay ay ay flaquito.";
        }
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 2;
          esperandoClic = true;
          if (segundaMisionGobierno) {
            documentos.generarDocumentos(2);
          }
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 2
      else if (faseAnimacion == 2) {

        fill(0);
        textSize(25);
        if (segundaMisionGobierno) {
          dialogo = "Tenemos un segundo objetivo,\nle tenes que dar esto";
        } else {
          dialogo="Yo confiaba en vos.\nSe ve que tenes otras ideas";
        }
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 3;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 3
      else if (faseAnimacion == 3) {

        fill(0);
        textSize(25);
        if (segundaMisionGobierno) {
          dialogo = "No sabemos bien como es, pero\npor la informacion que nos dieron\nsabemos que es morocho de ojos azules.\nDe unos 60. Espero que no me falles";
        } else {
          dialogo="Pero bueno. Es asi,\nde momento no te voy a\nbotonear, por ahora...";
        }
        textAlign(LEFT);

        text(dialogo, width / 4, height / 8);

        if (mousePressed && !esperandoClic) {
          faseAnimacion = 4;
          esperandoClic = true;
        }

        if (!mousePressed) {
          esperandoClic = false;
        }
      }

      // FASE 4: animación terminada
      else if (faseAnimacion == 4) {
        animacionTerminada = true;
        animacionEnCurso = false;
      }
    }
  }

  void animacionNarco(boolean pasa) {
    if (tarjeta.tarjetaDevuelta == false || pasa == false) {
      finalJuego = 2;
      asesinado = true;
      finalJuego = 2;
    } else {
      personajesAtendidos++;
      personaje.nuevoPersonaje();
      segundaMisionOrganizacion = true;
      //}
    }



    //FINALES
  }
}
