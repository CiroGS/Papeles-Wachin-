import processing.sound.*;

SoundFile musica;

PImage fondo;
PImage garita;
PImage imgCara;
PImage imgPelo;
PImage imgBarbijo;
PImage imgArma;
PImage liderCara;
PImage frame;

Menu menu;
Juego juego;
Personaje personaje;
Pasaporte pasaporte;
DNI dni;
BotonPasa botonPasa;
BotonNoPasa botonNoPasa;
Verificacion verificacion;
Fecha fecha;
Cinematica cinematica;
FinalDia finaldia;
Dinero dinero;
Permiso permiso;
Barbijo barbijo;
Manual manual;
Dialogo dialogo;
Tarjeta tarjeta;
Animaciones animaciones;
Arma arma;
Documentos documentos;
Veneno veneno;

int estado = 0;
int anchoCara = 30;
int largoCara = 35;
int anchoPelo = 34;
int largoPelo = 10;

int personajesAtendidos; //Cantidad de personajes que el jugador denego o aprobo para pasar
// 0 = menú
// 1 = juego
// 2 = Cinematica
// 3 = Game over
// 4 = Pantalla final del dia
// 5 = Final del juego



//
//MISIONES
//Mision Marcos Lunas
boolean primerMisionOrganizacion = false;
boolean segundaMisionOrganizacion = false;
boolean terceraMisionOrganizacion = false;
boolean primerMisionGobierno = false;
boolean segundaMisionGobierno = false;
boolean terceraMisionGobierno = false;

int finalJuego;

boolean asesinado, escapo, familia;

void setup() {

  fullScreen();

  musica = new SoundFile(this, "musica.mp3");

  musica.loop();




  fondo = loadImage("menu.png");
  garita = loadImage("garita.png");
  botonPasa = new BotonPasa();
  botonNoPasa = new BotonNoPasa();
  verificacion = new Verificacion();
  permiso = new Permiso();
  fecha = new Fecha();
  cinematica = new Cinematica();
  finaldia = new FinalDia();
  dinero = new Dinero();
  menu = new Menu();
  juego = new Juego();
  dni = new DNI();
  pasaporte = new Pasaporte();
  personaje = new Personaje();
  barbijo = new Barbijo();
  manual = new Manual();
  dialogo = new Dialogo();
  tarjeta = new Tarjeta();
  animaciones = new Animaciones();
  arma = new Arma();
  documentos = new Documentos();
  veneno = new Veneno();

  personaje.crearPersonaje();
  personaje.datosdebug();
  imgCara = loadImage("cara0.png");
  imgPelo = loadImage("pelo0.png");
}

void draw() {
  if (estado == 0) {
    menu.mostrar();
    textSize(30);
    text("version 1.0 ||", 20, height - 20);
  } else if (estado == 1) {
    juego.mostrar();
  } else if (estado == 2) {
    cinematica.mostrar();
  } else if (estado == 4) {
    finaldia.pantalla();
  }
  mostrarFinal();
  

  fecha.chequearDia();
}

void mouseReleased() {
  if (estado == 1) {
    pasaporte.mouseReleased();
    dni.mouseReleased();
    permiso.mouseReleased();
    manual.mouseReleased();
    tarjeta.mouseReleased();
    arma.mouseReleased();
    documentos.mouseReleased();
    veneno.mouseReleased();
  }
}


void mousePressed() {
  if (estado == 0) {
    if (mouseX >= width / 2 - 150 && mouseX <= width / 2 + 150 && mouseY >= height * 0.65 && mouseY <= height * 0.65 + 70) {
      print("ja");
      estado = 2;
    }
  }
  if (estado == 1) {
    pasaporte.mousePressed();
    dni.mousePressed();
    botonPasa.mousePressed();
    botonNoPasa.mousePressed();
    permiso.mousePressed();
    manual.mousePressed();
    dialogo.mousePressed();
    tarjeta.mousePressed();
    arma.mousePressed();
    documentos.mousePressed();
    veneno.mousePressed();
  }
  if (estado == 2) {
    cinematica.mousePressed();
  }

  if (estado == 4) {
    finaldia.mousePressed();
    dinero.mousePressed();
  }
}

void comprobarFinal() {



  // FINAL 2: Es asesinado
  if (asesinado) {
    finalJuego = 2;
  }

  // FINAL 3: Escapa solo
  else if (escapo && !familia) {
    finalJuego = 3;
  }

  // FINAL 4: Escapa con su familia
  else if (escapo && familia) {
    finalJuego = 4;
  }


  // FINAL 6: Ayudó a la organización y dejó pasar al Turro
  else if (primerMisionOrganizacion &&
    segundaMisionOrganizacion &&
    terceraMisionOrganizacion) {
    finalJuego = 6;
  }

  // FINAL 7: Asesinó al inspector, pero no dejó pasar al Turro
  else if (!primerMisionOrganizacion &&
    segundaMisionOrganizacion &&
    terceraMisionOrganizacion) {
    finalJuego = 7;
  }

  // FINAL 8: Ayudó al gobierno a derrotar a la organización
  else if (primerMisionGobierno &&
    segundaMisionGobierno &&
    terceraMisionGobierno) {
    finalJuego = 8;
  }
  // FINAL 5: No hizo nada y cayó el gobierno
  else {
    finalJuego = 5;
  }
}

void mostrarFinal() {
  if (finalJuego != 0) {
    estado = 5;
  }
  if (finalJuego == 1) {
    print("FINAL 1");
  }
  if (finalJuego == 2) {
    print("FINAL 2 (asesinado)");
    cinematica.mostrarFinal2();
  }
  if (finalJuego == 3) {
    print("FINAL 3");
  }
  if (finalJuego == 4) {
    print("FINAL 4");
  }
  if (finalJuego == 5) {
    print("FINAL 5");
  }
  if (finalJuego == 6) {
    print("FINAL 6");
  }
  if (finalJuego == 7) {
    print("FINAL 7");
  }
  if (finalJuego == 8) {
    print("FINAL 8");
  }
}
