class Pasaporte {

  int estadoPasaporte;
  boolean agarrado, estado;

  String nombre;
  String apellido;
  String nacionalidad;
  String ciudad;

  int numero;
  int emision;
  int vencimiento;
  
  int largo, ancho, vencidoNum;
  boolean vencido;
  float offsetX, offsetY;

  float x, y; //posiscion del pasaporte

  Pasaporte() {
    generarPasaporte();
  }


  void generarPasaporte() {
    x = width / 150;
    y = height - height / 3;
    ancho = 100;
    largo = 50;
    estado = true;

    numero = int(random(10000000, 99999999));

    vencidoNum = int(random(4));
    if(vencidoNum == 1){
      vencido = true;
      estado = false;
      vencimiento = int(random(2018, 2019));
    } else{
      vencido = false;
      vencimiento = int(random(2021, 2040));
    }
    
    emision = vencimiento - int(random(1, 6));
    if(emision >2020){emision = 2020;}
  }


  void mostrar() {

    // Pasaporte
    fill(100);
    rect(x, y, ancho, largo);
    fill(255);
    if(x <= width /2){
      text("Pasaporte", x+ancho/4, y+largo/2);
    }
    
    if (x > width / 2){
      mostrarDatos();
    }
  }
  
  void mousePressed(){
    if (mouseX >= x &&
        mouseX <= x + ancho &&
        mouseY >= y &&
        mouseY <= y + largo) {
          agarrado = true;
          offsetX = mouseX - x;
          offsetY = mouseY - y;
  }
  }
  
  void mouseReleased(){
    agarrado = false;
  }
  
  void actualizar(){
    if(agarrado){
      x = mouseX - offsetX;
      y = mouseY - offsetY;
      
      if(x>width/2){
        ancho = 400;
        largo = 300;
      } else {
        ancho = 100;
        largo = 50;
      }
    }
  }  
  
  
  void mostrarDatos() {

    fill(255);
  
    textSize(24);
    text("PASAPORTE", x + 20, y + 35);
  
    textSize(18);
  
    if(nombre !=null){
      text("Nombre:", x + 20, y + 80);
      text(personaje.nombre, x + 130, y + 80);
    }
  
    if(apellido != null){
      text("Apellido:", x + 20, y + 110);
      text(apellido, x + 130, y + 110);
    }
  
    if(nacionalidad != null){
      text("Nacionalidad:", x + 20, y + 140);
      text(nacionalidad, x + 160, y + 140);
    }
  
    if(ciudad != null){
      text("Ciudad:", x + 20, y + 170);
      text(ciudad, x + 130, y + 170);
    }
  
    text("Número:", x + 20, y + 200);
    text(numero, x + 130, y + 200);
  
    text("Emisión:", x + 20, y + 230);
    text(emision, x + 130, y + 230);
  
    text("Vencimiento:", x + 20, y + 260);
    text(vencimiento, x + 160, y + 260);
}
}
