class Juego {

  void mostrar() {
    float escala = max(
      (float)width / garita.width,
      (float)height / garita.height
      );

    float ancho = fondo.width * escala;
    float alto = fondo.height * escala;

    float x = (width - ancho) / 2;
    float y = (height - alto) / 2;

    image(garita, x, y, ancho, alto);
    botonPasa.mostrar();
    botonNoPasa.mostrar();

    //dia 1
    personaje.mostrar();
    verificacion.mostrarPenalizacion();
    if (personaje.extranjero) {
      pasaporte.mostrar();
      pasaporte.actualizar();
    } else {
      dni.mostrar();
      dni.actualizar();
    }
  }
}
