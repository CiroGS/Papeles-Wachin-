PImage fondo;
PImage garita;
PImage imgCara;
PImage imgPelo;

Menu menu;
Juego juego;
Personaje personaje;
Pasaporte pasaporte;
DNI dni;
BotonPasa botonPasa;
BotonNoPasa botonNoPasa;
Verificacion verificacion;

int estado = 0;
int anchoCara = 30;
int largoCara = 35;
int anchoPelo = 34;
int largoPelo = 10;
// 0 = menú
// 1 = juego
// 2 = instrucciones

void setup() {

  fullScreen();


  fondo = loadImage("menu.png");
  garita = loadImage("garita.png");

  menu = new Menu();
  juego = new Juego();

  dni = new DNI();
  pasaporte = new Pasaporte();

  personaje = new Personaje();

  personaje.crearPersonaje();
  personaje.datosdebug();

  botonPasa = new BotonPasa();
  botonNoPasa = new BotonNoPasa();
  verificacion = new Verificacion();
}

void draw() {
  if (estado == 0) {
    menu.mostrar();
  } else if (estado == 1) {
    juego.mostrar();
  }
}

void mouseReleased() {
  pasaporte.mouseReleased();
  dni.mouseReleased();
}


void mousePressed() {
  if (estado == 0) {
    if (mouseX >= width / 2 - 150 && mouseX <= width / 2 + 150 && mouseY >= height * 0.65 && mouseY <= height * 0.65 + 70) {
      print("ja");
      estado = 1;
    }
  }
  if (estado == 1) {
    pasaporte.mousePressed();
    dni.mousePressed();
    botonPasa.mousePressed();
    botonNoPasa.mousePressed();
  }
}
