class BotonNoPasa{
  int x, y, ancho, largo;
  
  BotonNoPasa(){
    x = width / 4;
    y = height - height / 10;
    ancho = 100;
    largo = 50;
  }
  void mostrar(){
    fill(255, 0, 0);
    rect(x, y, 100, 50);
  }

  void mousePressed(){

  if(mouseX >= x &&
     mouseX <= x + ancho &&
     mouseY >= y &&
     mouseY <= y + largo){

    verificacion.verificarNoPasa();
    personaje.nuevoPersonaje();
  }
}

}
