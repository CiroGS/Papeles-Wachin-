class BotonPasa{
  int x, y, ancho, largo;
  
  BotonPasa(){
    x = width / 8;
    y = height - height / 10;
    ancho = 100;
    largo = 50;
  }
  void mostrar(){
    fill(0, 255, 0);
    rect(x, y, ancho, largo);
  }
  
  void mousePressed(){
    if(mouseX >=width / 8 &&
    mouseX <= width / 8 + ancho &&
    mouseY >= height - height / 10 &&
    mouseY <= height - height / 10 + largo){
      verificacion.verificarPasa();
      personaje.nuevoPersonaje();
    }
  }
}
