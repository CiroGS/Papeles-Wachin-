class Personaje{

  float x, y;
  int nacionalidadNum, pais; //0 Argentina - 1 Brasil - 2 Paraguay - 3 Bolivia - 4 Chile - 5 Uruguay
  boolean extranjero, genero; //extranjero 0 es Argentino/a - 1 es Extranjero // genero 0 es masculino 1 es femenino // verificacion 0 si no puede pasar 1 si puede pasar
  
  String nombre;
  String ciudad;
  String provincia;
  String nacionalidad;
  String apellido;
  
  int estadoPasaporte, estadoDNI; //si es 0 esta mal

  String[] nombres = { //10 nombres masculinos (0 al 9) y 10 femeninos (10 al 19)
    "Juan",
    "Pedro",
    "Lucas",
    "Mateo",
    "Santiago",
    "Martín",
    "Nicolás",
    "Tomás",
    "Facundo",
    "Franco",
    "Sofía",
    "Valentina",
    "Camila",
    "Martina",
    "Julieta",
    "Agustina",
    "Lucía",
    "Micaela",
    "Carolina",
    "Florencia"
  };
  String[] apellidos = {
    "Gonzalez",
    "Rodriguez",
    "Fernandez",
    "Lopez",
    "Martinez",
    "Perez",
    "Garcia",
    "Sanchez",
    "Romero",
    "Diaz",
    "Torres",
    "Alvarez",
    "Ruiz",
    "Sosa",
    "Acosta",
    "Benitez",
    "Medina",
    "Herrera",
    "Suarez",
    "Rojas"
  };
  
  String[] ciudadesBrasil = { //1
  "Brasilia",
  "Rio de Janeiro",
  "Sao Paulo",
  "Florianopolis",
  "Salvador",
  "Belo Horizonte"
};

String[] ciudadesParaguay = { //2
  "Asuncion",
  "Ciudad del Este",
  "Encarnacion",
  "Luque",
  "San Lorenzo",
  "Pedro Juan Caballero"
};

String[] ciudadesBolivia = { //3
  "La Paz",
  "Santa Cruz de la Sierra",
  "Cochabamba",
  "Sucre",
  "Oruro",
  "Potosi"
};

String[] ciudadesChile = { //4
  "Santiago",
  "Valparaiso",
  "Concepcion",
  "Antofagasta",
  "Temuco",
  "Puerto Montt"
};

String[] ciudadesUruguay = { //5
  "Montevideo",
  "Salto",
  "Paysandu",
  "Maldonado",
  "Rivera",
  "Colonia del Sacramento"
};

String[] provinciasArgentina = {
  "Buenos Aires",
  "Catamarca",
  "Chaco",
  "Chubut",
  "Cordoba",
  "Corrientes",
  "Entre Rios",
  "Formosa",
  "Jujuy",
  "La Pampa",
  "La Rioja",
  "Mendoza",
  "Misiones",
  "Neuquen",
  "Rio Negro",
  "Salta",
  "San Juan",
  "San Luis",
  "Santa Cruz",
  "Santa Fe",
  "Santiago del Estero",
  "Tierra del Fuego",
  "Tucuman",
  "CABA"
};

  
  
  Personaje() {
      
    }
  
    void mostrar() {
      
      imgCara = loadImage(caraPersonaje);
      imgCara.resize(anchoCara * 4, largoCara * 4);
      image(imgCara, x, y);
      
      imgPelo = loadImage(peloPersonaje);
      imgPelo.resize(anchoPelo * 4, largoPelo * 4);
      image(imgPelo, x - anchoPelo/4, y - largoPelo*4);
  
    }
    
    void crearPersonaje(){
    
       x = width / 7;
       y = height / 10;
       
       crearApariencia();
      
       //nacionalidad:
       nacionalidadNum = int(random(5));
       if(nacionalidadNum == 0){extranjero = true;} else {extranjero = false;}
       if(extranjero == true){pais = int(random(1, 6));}else{pais = 0;}
       
       //ciudad de nacimiento
       if(pais == 1){
         ciudad = ciudadesBrasil[int(random(6))];
         nacionalidad = "Brasil";
       }
       if(pais == 2){
         ciudad = ciudadesParaguay[int(random(6))];
         nacionalidad = "Paraguay";
       }
       if(pais == 3){
         ciudad = ciudadesBolivia[int(random(6))];
         nacionalidad = "Bolivia";
       }
       if(pais == 4){
         ciudad = ciudadesChile[int(random(6))];
         nacionalidad = "Chile";
       }
       if(pais == 5){
         ciudad = ciudadesUruguay[int(random(6))];
         nacionalidad = "Uruguay";
       }
       
       if (pais == 0){
         nacionalidad = "Argentina";
           provincia = provinciasArgentina[int(random(24))];
       }
       
       
       //genero y nombre
       int generoInt = int(random(2));
       if(generoInt == 1){
         genero = true;
         nombre = nombres[int(random(0, 10))];
       }else{
         genero=false;
         nombre = nombres[int(random(10, 20))];
       }
       
       apellido = apellidos[int(random(20))];
    
      
       
       
       if(extranjero){
         generarPasaporte();
       } else{
         generarDNI();
       }
    
    }
    
    
    void generarPasaporte(){
      pasaporte.nombre = nombre;
      pasaporte.nacionalidad = nacionalidad;
      pasaporte.ciudad = ciudad;
      pasaporte.apellido = apellido;
    
      pasaporte.generarPasaporte();
    }
    
    
    void generarDNI(){
      dni.nombre = nombre;
      dni.nacionalidad = nacionalidad;
      dni.provincia = provincia;
      dni.apellido = apellido;
      
      dni.generarDNI();
    }
    
    void datosdebug(){
      println("----------------------");
      println("Pais: " + pais);
      println("Extranjero: " + extranjero);
      println("Genero: " + genero);
      println("Nombre: " + nombre);
      println("Ciudad: " + ciudad);
      println("Provincia: " + provincia);
    }
    
    
    void nuevoPersonaje() {

  personaje = new Personaje();
  personaje.crearPersonaje();

  }
  
  
  String[] caras = { //sprites de las caras
    "cara0.png",
    "cara1.png"
  };
  
  String[] pelos = {
    "pelo0.png",
    "pelo1.png"
  };
  
  String peloPersonaje;
  String caraPersonaje;
  
  void crearApariencia(){ // Crea el Pelo, altura, peso, y cara del personaje
    caraPersonaje = caras[int(random(caras.length))];
    peloPersonaje = pelos[int(random(pelos.length))];
  }



}
